package com.stb.poc.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.stb.poc.MVSinkTask;
import com.stb.poc.models.source.SrcBankAccount;
import com.stb.poc.models.source.SrcLdSchedule;
import com.stb.poc.models.target.TrgBankAccount;
import com.stb.poc.models.target.TrgLdSchedule;
import com.stb.poc.util.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OGGRecord {
    private static final Logger LOGGER = LoggerFactory.getLogger(OGGRecord.class);

    @JsonProperty("table")
    public String table;

    @JsonProperty("op_type")
    public String op_type;

    @JsonProperty("op_ts")
    public String op_ts;

    @JsonProperty("current_ts")
    public String current_ts;

    @JsonProperty("pos")
    public String pos;

    @JsonProperty("before")
    public Object before;

    @JsonProperty("after")
    public Object after;

    public Map<String, Object> content;

    public void save(Session session){
        if(table.contains("SRC_T24_BNK_ACCOUNT")){
            saveAccount(session);
        }
        else{
            if(table.contains("SRC_T24_BNK_LD_SCHEDULE_DEFINE")){
                saveSchedule(session);
            }
        }
    }

    private void saveAccount(Session session){
        Transaction transaction = session.beginTransaction();

        if(op_type.equals("I") || op_type.equals("U")){
            SrcBankAccount srcBankAccount = (SrcBankAccount)content.get("after");
            String[] localRefs;
            if(srcBankAccount.LOCAL_REF == null){
                localRefs = new String[0];
            }
            else{
               localRefs = srcBankAccount.LOCAL_REF.split("\uF8FD");
            }

                TrgBankAccount trgBankAccount = new TrgBankAccount();
                trgBankAccount.FIC_MIS_DATE = Utils.Str2Date(srcBankAccount.MIS_DATE, "yyyyMMdd");
                trgBankAccount.V_DATA_ORIGIN = "BI_MIS";
                trgBankAccount.V_ACCOUNT_NUMBER = srcBankAccount.ID;
                trgBankAccount.V_CATEGORY = srcBankAccount.CATEGORY;

                int count = 0;
                try{
                    trgBankAccount.V_LOCAL_REF_1 = localRefs[0];count++;
                    trgBankAccount.V_LOCAL_REF_2 = localRefs[1];count++;
                    trgBankAccount.V_LOCAL_REF_3 = localRefs[2];count++;
                    trgBankAccount.V_LOCAL_REF_4 = localRefs[3];count++;
                    trgBankAccount.V_LOCAL_REF_5 = localRefs[4];count++;
                    trgBankAccount.V_LOCAL_REF_6 = localRefs[5];count++;
                    trgBankAccount.V_LOCAL_REF_7 = localRefs[6];count++;
                    trgBankAccount.V_LOCAL_REF_8 = localRefs[7];count++;
                    trgBankAccount.V_LOCAL_REF_9 = localRefs[8];count++;
                    trgBankAccount.V_LOCAL_REF_10 = localRefs[9];count++;
                    trgBankAccount.V_LOCAL_REF_11 = localRefs[10];count++;
                    trgBankAccount.V_LOCAL_REF_12 = localRefs[11];count++;
                    trgBankAccount.V_LOCAL_REF_13 = localRefs[12];count++;
                    trgBankAccount.V_LOCAL_REF_14 = localRefs[13];count++;
                    trgBankAccount.V_LOCAL_REF_15 = localRefs[14];count++;
                    trgBankAccount.V_LOCAL_REF_16 = localRefs[15];count++;
                    trgBankAccount.V_LOCAL_REF_17 = localRefs[16];count++;
                    trgBankAccount.V_LOCAL_REF_18 = localRefs[17];count++;
                    trgBankAccount.V_LOCAL_REF_19 = localRefs[18];count++;
                    trgBankAccount.V_LOCAL_REF_20 = localRefs[19];count++;
                    trgBankAccount.V_LOCAL_REF_21 = localRefs[20];count++;
                    trgBankAccount.V_LOCAL_REF_22 = localRefs[21];count++;
                    trgBankAccount.V_LOCAL_REF_23 = localRefs[22];count++;
                    trgBankAccount.V_LOCAL_REF_24 = localRefs[23];count++;
                    trgBankAccount.V_LOCAL_REF_25 = localRefs[24];count++;
                    trgBankAccount.V_LOCAL_REF_26 = localRefs[25];count++;
                    trgBankAccount.V_LOCAL_REF_27 = localRefs[26];count++;
                    trgBankAccount.V_LOCAL_REF_27 = localRefs[26];count++;
                    trgBankAccount.V_LOCAL_REF_28 = localRefs[27];count++;
                    trgBankAccount.V_LOCAL_REF_29 = localRefs[28];count++;
                    trgBankAccount.V_LOCAL_REF_30 = localRefs[29];count++;
                    trgBankAccount.V_LOCAL_REF_31 = localRefs[30];count++;
                    trgBankAccount.V_LOCAL_REF_32 = localRefs[31];count++;
                    trgBankAccount.V_LOCAL_REF_33 = localRefs[32];count++;
                    trgBankAccount.V_LOCAL_REF_34 = localRefs[33];count++;
                    trgBankAccount.V_LOCAL_REF_35 = localRefs[34];count++;
                    trgBankAccount.V_LOCAL_REF_36 = localRefs[35];count++;
                    trgBankAccount.V_LOCAL_REF_37 = localRefs[36];count++;
                    trgBankAccount.V_LOCAL_REF_38 = localRefs[37];count++;
                    trgBankAccount.V_LOCAL_REF_39 = localRefs[38];count++;
                    trgBankAccount.V_LOCAL_REF_40 = localRefs[39];count++;
                    trgBankAccount.V_LOCAL_REF_41 = localRefs[40];count++;
                    trgBankAccount.V_LOCAL_REF_42 = localRefs[41];count++;
                    trgBankAccount.V_LOCAL_REF_43 = localRefs[42];count++;
                    trgBankAccount.V_LOCAL_REF_44 = localRefs[43];count++;
                    trgBankAccount.V_LOCAL_REF_45 = localRefs[44];count++;
                    trgBankAccount.V_LOCAL_REF_46 = localRefs[45];count++;
                    trgBankAccount.V_LOCAL_REF_47 = localRefs[46];count++;
                    trgBankAccount.V_LOCAL_REF_48 = localRefs[47];count++;
                    trgBankAccount.V_LOCAL_REF_49 = localRefs[48];count++;
                    trgBankAccount.V_LOCAL_REF_50 = localRefs[49];count++;
                    trgBankAccount.V_LOCAL_REF_51 = localRefs[50];count++;
                    trgBankAccount.V_LOCAL_REF_52 = localRefs[51];count++;
                    trgBankAccount.V_LOCAL_REF_53 = localRefs[52];count++;
                    trgBankAccount.V_LOCAL_REF_54 = localRefs[53];count++;
                    trgBankAccount.V_LOCAL_REF_55 = localRefs[54];count++;
                    trgBankAccount.V_LOCAL_REF_56 = localRefs[55];count++;
                    trgBankAccount.V_LOCAL_REF_57 = localRefs[56];count++;
                    trgBankAccount.V_LOCAL_REF_58 = localRefs[57];count++;
                    trgBankAccount.V_LOCAL_REF_59 = localRefs[58];count++;
                    trgBankAccount.V_LOCAL_REF_60 = localRefs[59];count++;
                    trgBankAccount.V_LOCAL_REF_61 = localRefs[60];count++;
                    trgBankAccount.V_LOCAL_REF_62 = localRefs[61];count++;
                    trgBankAccount.V_LOCAL_REF_63 = localRefs[62];count++;
                    trgBankAccount.V_LOCAL_REF_64 = localRefs[63];count++;
                    trgBankAccount.V_LOCAL_REF_65 = localRefs[64];count++;
                    trgBankAccount.V_LOCAL_REF_66 = localRefs[65];count++;
                    trgBankAccount.V_LOCAL_REF_67 = localRefs[66];count++;
                    trgBankAccount.V_LOCAL_REF_68 = localRefs[67];count++;
                    trgBankAccount.V_LOCAL_REF_69 = localRefs[68];count++;
                    trgBankAccount.V_LOCAL_REF_70 = localRefs[69];count++;
                    trgBankAccount.V_LOCAL_REF_71 = localRefs[70];count++;
                    trgBankAccount.V_LOCAL_REF_72 = localRefs[71];count++;
                    trgBankAccount.V_LOCAL_REF_73 = localRefs[72];count++;
                    trgBankAccount.V_LOCAL_REF_74 = localRefs[73];count++;
                    trgBankAccount.V_LOCAL_REF_75 = localRefs[74];count++;
                    trgBankAccount.V_LOCAL_REF_76 = localRefs[75];count++;
                    trgBankAccount.V_LOCAL_REF_77 = localRefs[76];count++;
                    trgBankAccount.V_LOCAL_REF_78 = localRefs[77];count++;
                    trgBankAccount.V_LOCAL_REF_79 = localRefs[78];count++;
                    trgBankAccount.V_LOCAL_REF_80 = localRefs[79];count++;
                    trgBankAccount.V_LOCAL_REF_81 = localRefs[80];count++;
                    trgBankAccount.V_LOCAL_REF_82 = localRefs[81];count++;
                    trgBankAccount.V_LOCAL_REF_83 = localRefs[82];count++;
                    trgBankAccount.V_LOCAL_REF_84 = localRefs[83];count++;
                    trgBankAccount.V_LOCAL_REF_85 = localRefs[84];count++;
                    trgBankAccount.V_LOCAL_REF_86 = localRefs[85];count++;
                    trgBankAccount.V_LOCAL_REF_87 = localRefs[86];count++;
                    trgBankAccount.V_LOCAL_REF_88 = localRefs[87];count++;
                    trgBankAccount.V_LOCAL_REF_89 = localRefs[88];count++;
                    trgBankAccount.V_LOCAL_REF_90 = localRefs[89];count++;
                    trgBankAccount.V_LOCAL_REF_91 = localRefs[90];count++;
                    trgBankAccount.V_LOCAL_REF_92 = localRefs[91];count++;
                    trgBankAccount.V_LOCAL_REF_93 = localRefs[92];count++;
                    trgBankAccount.V_LOCAL_REF_94 = localRefs[93];count++;
                    trgBankAccount.V_LOCAL_REF_95 = localRefs[94];count++;
                    trgBankAccount.V_LOCAL_REF_96 = localRefs[95];count++;
                    trgBankAccount.V_LOCAL_REF_97 = localRefs[96];count++;
                    trgBankAccount.V_LOCAL_REF_98 = localRefs[97];count++;
                    trgBankAccount.V_LOCAL_REF_99 = localRefs[98];count++;
                    trgBankAccount.V_LOCAL_REF_100 = localRefs[99];count++;
                    trgBankAccount.V_LOCAL_REF_101 = localRefs[100];count++;
                    trgBankAccount.V_LOCAL_REF_102 = localRefs[101];count++;
                    trgBankAccount.V_LOCAL_REF_103 = localRefs[102];count++;
                    trgBankAccount.V_LOCAL_REF_104 = localRefs[103];count++;
                    trgBankAccount.V_LOCAL_REF_105 = localRefs[104];count++;
                    trgBankAccount.V_LOCAL_REF_106 = localRefs[105];count++;
                    trgBankAccount.V_LOCAL_REF_107 = localRefs[106];count++;
                    trgBankAccount.V_LOCAL_REF_108 = localRefs[107];count++;
                    trgBankAccount.V_LOCAL_REF_109 = localRefs[108];count++;
                    trgBankAccount.V_LOCAL_REF_110 = localRefs[109];count++;
                    trgBankAccount.V_LOCAL_REF_111 = localRefs[110];count++;
                    trgBankAccount.V_LOCAL_REF_112 = localRefs[111];count++;
                    trgBankAccount.V_LOCAL_REF_113 = localRefs[112];count++;
                    trgBankAccount.V_LOCAL_REF_114 = localRefs[113];count++;
                    trgBankAccount.V_LOCAL_REF_115 = localRefs[114];count++;
                    trgBankAccount.V_LOCAL_REF_116 = localRefs[115];count++;
                    trgBankAccount.V_LOCAL_REF_117 = localRefs[116];count++;
                    trgBankAccount.V_LOCAL_REF_118 = localRefs[117];count++;
                    trgBankAccount.V_LOCAL_REF_119 = localRefs[118];count++;
                    trgBankAccount.V_LOCAL_REF_120 = localRefs[119];count++;
                    trgBankAccount.V_LOCAL_REF_121 = localRefs[120];count++;
                    trgBankAccount.V_LOCAL_REF_122 = localRefs[121];count++;
                    trgBankAccount.V_LOCAL_REF_123 = localRefs[122];count++;
                    trgBankAccount.V_LOCAL_REF_124 = localRefs[123];count++;
                    trgBankAccount.V_LOCAL_REF_125 = localRefs[124];count++;
                    trgBankAccount.V_LOCAL_REF_126 = localRefs[125];count++;
                    trgBankAccount.V_LOCAL_REF_127 = localRefs[126];count++;
                    trgBankAccount.V_LOCAL_REF_128 = localRefs[127];count++;
                    trgBankAccount.V_LOCAL_REF_129 = localRefs[128];count++;
                    trgBankAccount.V_LOCAL_REF_130 = localRefs[129];count++;
                    trgBankAccount.V_LOCAL_REF_131 = localRefs[130];count++;
                    trgBankAccount.V_LOCAL_REF_132 = localRefs[131];count++;
                    trgBankAccount.V_LOCAL_REF_133 = localRefs[132];count++;
                    trgBankAccount.V_LOCAL_REF_134 = localRefs[133];count++;
                    trgBankAccount.V_LOCAL_REF_135 = localRefs[134];count++;
                    trgBankAccount.V_LOCAL_REF_136 = localRefs[135];count++;
                    trgBankAccount.V_LOCAL_REF_137 = localRefs[136];count++;
                    trgBankAccount.V_LOCAL_REF_138 = localRefs[137];count++;
                    trgBankAccount.V_LOCAL_REF_139 = localRefs[138];count++;
                    trgBankAccount.V_LOCAL_REF_140 = localRefs[139];count++;
                    trgBankAccount.V_LOCAL_REF_141 = localRefs[140];count++;
                    trgBankAccount.V_LOCAL_REF_142 = localRefs[141];count++;
                    trgBankAccount.V_LOCAL_REF_143 = localRefs[142];count++;
                    trgBankAccount.V_LOCAL_REF_144 = localRefs[143];count++;
                    trgBankAccount.V_LOCAL_REF_145 = localRefs[144];count++;
                    trgBankAccount.V_LOCAL_REF_146 = localRefs[145];count++;
                    trgBankAccount.V_LOCAL_REF_147 = localRefs[146];count++;
                    trgBankAccount.V_LOCAL_REF_148 = localRefs[147];count++;
                    trgBankAccount.V_LOCAL_REF_149 = localRefs[148];count++;
                    trgBankAccount.V_LOCAL_REF_150 = localRefs[149];count++;
                    trgBankAccount.V_LOCAL_REF_151 = localRefs[150];count++;
                    trgBankAccount.V_LOCAL_REF_152 = localRefs[151];count++;
                    trgBankAccount.V_LOCAL_REF_153 = localRefs[152];count++;
                    trgBankAccount.V_LOCAL_REF_154 = localRefs[153];count++;
                    trgBankAccount.V_LOCAL_REF_155 = localRefs[154];count++;
                    trgBankAccount.V_LOCAL_REF_156 = localRefs[155];count++;
                    trgBankAccount.V_LOCAL_REF_157 = localRefs[156];count++;
                    trgBankAccount.V_LOCAL_REF_158 = localRefs[157];count++;
                    trgBankAccount.V_LOCAL_REF_159 = localRefs[158];count++;
                    trgBankAccount.V_LOCAL_REF_160 = localRefs[159];count++;
                    trgBankAccount.V_LOCAL_REF_161 = localRefs[160];count++;
                    trgBankAccount.V_LOCAL_REF_162 = localRefs[161];count++;
                    trgBankAccount.V_LOCAL_REF_163 = localRefs[162];count++;
                    trgBankAccount.V_LOCAL_REF_164 = localRefs[163];count++;
                    trgBankAccount.V_LOCAL_REF_165 = localRefs[164];count++;
                    trgBankAccount.V_LOCAL_REF_166 = localRefs[165];count++;
                    trgBankAccount.V_LOCAL_REF_167 = localRefs[166];count++;
                    trgBankAccount.V_LOCAL_REF_168 = localRefs[167];count++;
                    trgBankAccount.V_LOCAL_REF_169 = localRefs[168];count++;
                    trgBankAccount.V_LOCAL_REF_170 = localRefs[169];count++;
                    trgBankAccount.V_LOCAL_REF_171 = localRefs[170];count++;
                    trgBankAccount.V_LOCAL_REF_172 = localRefs[171];count++;
                    trgBankAccount.V_LOCAL_REF_173 = localRefs[172];count++;
                    trgBankAccount.V_LOCAL_REF_174 = localRefs[173];count++;
                    trgBankAccount.V_LOCAL_REF_175 = localRefs[174];count++;
                    trgBankAccount.V_LOCAL_REF_176 = localRefs[175];count++;
                    trgBankAccount.V_LOCAL_REF_177 = localRefs[176];count++;
                    trgBankAccount.V_LOCAL_REF_178 = localRefs[177];count++;
                    trgBankAccount.V_LOCAL_REF_179 = localRefs[178];count++;
                    trgBankAccount.V_LOCAL_REF_180 = localRefs[179];count++;
                    trgBankAccount.V_LOCAL_REF_181 = localRefs[180];count++;
                    trgBankAccount.V_LOCAL_REF_182 = localRefs[181];count++;
                    trgBankAccount.V_LOCAL_REF_183 = localRefs[182];count++;
                    trgBankAccount.V_LOCAL_REF_184 = localRefs[183];count++;
                    trgBankAccount.V_LOCAL_REF_185 = localRefs[184];count++;
                    trgBankAccount.V_LOCAL_REF_186 = localRefs[185];count++;
                    trgBankAccount.V_LOCAL_REF_187 = localRefs[186];count++;
                    trgBankAccount.V_LOCAL_REF_188 = localRefs[187];count++;
                    trgBankAccount.V_LOCAL_REF_189 = localRefs[188];count++;
                    trgBankAccount.V_LOCAL_REF_190 = localRefs[189];count++;
                    trgBankAccount.V_LOCAL_REF_191 = localRefs[190];count++;
                    trgBankAccount.V_LOCAL_REF_192 = localRefs[191];count++;
                    trgBankAccount.V_LOCAL_REF_193 = localRefs[192];count++;
                    trgBankAccount.V_LOCAL_REF_194 = localRefs[193];count++;
                    trgBankAccount.V_LOCAL_REF_195 = localRefs[194];count++;
                    trgBankAccount.V_LOCAL_REF_196 = localRefs[195];count++;
                    trgBankAccount.V_LOCAL_REF_197 = localRefs[196];count++;
                    trgBankAccount.V_LOCAL_REF_198 = localRefs[197];count++;
                    trgBankAccount.V_LOCAL_REF_199 = localRefs[198];count++;
                    trgBankAccount.V_LOCAL_REF_200 = localRefs[199];count++;
                    trgBankAccount.D_ETL_DATE = srcBankAccount.ETL_DATE;
                    trgBankAccount.BOOKMARK = pos;

                    count++;
                }
                catch (Exception ex){
                    LOGGER.info("LocalRefs size = " + count);
                }

                session.merge(trgBankAccount);
            }

        else {
            if (op_type.equals("D")) {
                SrcBankAccount srcBankAccount = (SrcBankAccount) content.get("before");
                TrgBankAccount trgBankAccount = new TrgBankAccount();
                trgBankAccount.V_ACCOUNT_NUMBER = srcBankAccount.ID;
                session.delete(trgBankAccount);
            }
        }

        session.flush();
        session.clear();
        transaction.commit();
    }

    private void saveSchedule(Session session){
        Transaction transaction = session.beginTransaction();

        if(op_type.equals("I") || op_type.equals("U")){
            SrcLdSchedule srcLdSchedule = (SrcLdSchedule)content.get("after");
            String[] cycledDates = srcLdSchedule.CYCLED_DATES.split("\uF8FD");
            int cycleSize = cycledDates.length;
            for(int i = 0; i < cycleSize; i++) {
                String[] subCycledDates = cycledDates[i].split("\uF8FC");
                int subCycleSize = subCycledDates.length;
                for(int j = 0; j < subCycleSize; j++){
                    TrgLdSchedule trgLdSchedule = new TrgLdSchedule();
                    trgLdSchedule.KEY = srcLdSchedule.ID + "-" + (i + 1);
                    trgLdSchedule.COL = subCycledDates[j];
                    trgLdSchedule.ROW_ORDER = "" + (j + 1);
                    trgLdSchedule.BOOKMARK = pos;

                    session.merge(trgLdSchedule);
                }
            }
        }
        else{
            if(op_type.equals("D")){
                SrcLdSchedule schedule = (SrcLdSchedule)content.get("before");
                //session.delete(schedule);
            }
        }

        session.flush();
        session.clear();
        transaction.commit();
    }
}
