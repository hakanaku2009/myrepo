package com.stb.poc.models.source;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.stb.poc.util.Utils;
import org.hibernate.Session;

import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SrcBankAccount {

    @JsonProperty("LEAD_CO_MNE")
    public String LEAD_CO_MNE;

    @JsonProperty("BRANCH_CO_MNE")
    public String BRANCH_CO_MNE;

    @JsonProperty("MIS_DATE")
    public String MIS_DATE;

    @JsonProperty("ID")
    public String ID;

    @JsonProperty("CUSTOMER")
    public String CUSTOMER;

    @JsonProperty("CATEGORY")
    public String CATEGORY;

    @JsonProperty("LOCAL_REF")
    public String LOCAL_REF;

    @JsonProperty("ETL_DATE")
    public String ETL_DATE_TEMP;

    public Date ETL_DATE;

    public void setETL_DATE_TEMP(String ETL_DATE_TEMP) {
        this.ETL_DATE_TEMP = ETL_DATE_TEMP;
        this.ETL_DATE = Utils.Str2Date(ETL_DATE_TEMP, "yyyy-MM-dd HH:mm:ss");
    }

    public void save(Session session, String operation){
        if(operation.equals("I") ||
                operation.equals("I")){

        }
        else{
            if(operation.equals("D")){

            }
        }
    }
}
