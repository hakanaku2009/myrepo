package com.stb.poc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.stb.poc.models.OGGRecord;
import com.stb.poc.models.source.SrcBankAccount;
import com.stb.poc.models.source.SrcLdSchedule;
import com.stb.poc.util.Version;
import org.apache.kafka.connect.sink.SinkRecord;
import org.apache.kafka.connect.sink.SinkTask;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class MVSinkTask extends SinkTask {
    private static final Logger LOGGER = LoggerFactory.getLogger(MVSinkTask.class);
    private ObjectMapper mapper = null;

    private Configuration hibernateConfiguration;
    private SessionFactory sessionFactory;
    private Session session = null;

    private String jdbc_url, jdbc_usr, jdbc_pwd, hibernateConfigFile = "file:///oracle/MVETL/hibernate.cfg.xml";

    @Override
    public String version() {
        LOGGER.info("In version.");
        return Version.getVersion();
    }

    @Override
    public void start(Map<String, String> map) {
        LOGGER.info("In start.");
        mapper = new ObjectMapper();

        getConnection();
    }

    private void getConnection(){
        hibernateConfiguration = new org.hibernate.cfg.Configuration().configure(hibernateConfigFile);
        sessionFactory = hibernateConfiguration.buildSessionFactory();
        session = sessionFactory.openSession();
    }

    private void closeConnection(){
        session.flush();
        session.clear();
        session.close();
    }

    @Override
    public void put(Collection<SinkRecord> records) {
        LOGGER.info("In put.");
        if(records.isEmpty()){
            return;
        }

        final SinkRecord first = records.iterator().next();
        final int recordsCount = records.size();
        LOGGER.info("Received {} records. First record kafka coordinates:({}-{}-{}). Splitting and writing them to the Oracle database...",
                recordsCount, first.topic(), first.kafkaPartition(), first.kafkaOffset());

        for (SinkRecord record : records) {
            OGGRecord oggRecord = mapper.convertValue(record.value(), OGGRecord.class);
            LOGGER.info("Offset {}: {}", record.kafkaOffset(), oggRecord.table);

            oggRecord.content = new HashMap<String, Object>();
            if(oggRecord.table.contains("SRC_T24_BNK_ACCOUNT")) {
                if(oggRecord.before != null) oggRecord.content.put("before", mapper.convertValue(oggRecord.before, SrcBankAccount.class));
                if(oggRecord.after != null) oggRecord.content.put("after", mapper.convertValue(oggRecord.after, SrcBankAccount.class));
            }
            else{
                if(oggRecord.table.contains("SRC_T24_BNK_LD_SCHEDULE_DEFINE")) {
                    if(oggRecord.before != null) oggRecord.content.put("before", mapper.convertValue(oggRecord.before, SrcLdSchedule.class));
                    if(oggRecord.after != null) oggRecord.content.put("after", mapper.convertValue(oggRecord.after, SrcLdSchedule.class));
                }
            }

            oggRecord.save(session);
        }
    }

    @Override
    public void stop() {
        LOGGER.info("In stop.");

        closeConnection();
    }
}
