package com.stb.poc.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Utils {
    public static Date Str2Date(String sdate, String format){
        if(sdate == null) return null;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        Date dateTime = null;
        try {
            dateTime = simpleDateFormat.parse(sdate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return (dateTime);
    }
}
