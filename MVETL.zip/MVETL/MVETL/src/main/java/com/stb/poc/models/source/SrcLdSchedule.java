package com.stb.poc.models.source;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.Session;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SrcLdSchedule {

    @JsonProperty("LEAD_CO_MNE")
    public String LEAD_CO_MNE;

    @JsonProperty("BRANCH_CO_MNE")
    public String BRANCH_CO_MNE;

    @JsonProperty("MIS_DATE")
    public String MIS_DATE;

    @JsonProperty("ID")
    public String ID;

    @JsonProperty("CURRENCY")
    public String CURRENCY;

    @JsonProperty("CYCLED_DATES")
    public String CYCLED_DATES;

    public void save(Session session, String operation){

    }
}
