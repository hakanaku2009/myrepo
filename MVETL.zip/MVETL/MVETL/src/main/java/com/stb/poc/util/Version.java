package com.stb.poc.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

public class Version {
    private static final Logger LOGGER = LoggerFactory.getLogger(Version.class);
    private static String version = "unknown";

    static {
        try {
            Properties props = new Properties();
            props.load(Version.class.getResourceAsStream("/mv-etl-version.properties"));
            version = props.getProperty("version", version).trim();
        } catch (Exception e) {
            LOGGER.warn("Error while loading version:", e);
        }
    }

    public static String getVersion() {
        return version;
    }
}