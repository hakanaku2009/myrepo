package com.stb.poc;

import com.stb.poc.util.Version;
import org.apache.kafka.common.config.ConfigDef;
import org.apache.kafka.connect.connector.Task;
import org.apache.kafka.connect.sink.SinkConnector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

    public class MVSinkConnector extends SinkConnector {
        private static final Logger LOGGER = LoggerFactory.getLogger(MVSinkConnector.class);
        private Map<String, String> configProperties;
        private static final ConfigDef CONFIG_DEF = new ConfigDef();

        @Override
        public String version() {
            LOGGER.info("In version.");
            return Version.getVersion();
        }

        @Override
        public void start(Map<String, String> properties) {
            configProperties = properties;
            LOGGER.info("In start.");
        }

        @Override
        public void stop() {
            LOGGER.info("In stop.");
        }

        @Override
        public ConfigDef config() {
            LOGGER.info("In config.");
            return CONFIG_DEF;
        }

        @Override
        public Class<? extends Task> taskClass() {
            LOGGER.info("In taskClass.");
            return MVSinkTask.class;
        }

        @Override
        public List<Map<String, String>> taskConfigs(int maxTasks) {
            List<Map<String, String>> taskConfigs = new ArrayList<>(maxTasks);
            for (int i = 0; i < maxTasks; i++) {
                taskConfigs.add(configProperties);
            }
            LOGGER.info("In taskConfigs.");
            return taskConfigs;
        }
    }

