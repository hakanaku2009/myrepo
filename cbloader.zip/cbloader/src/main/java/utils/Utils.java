package utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Utils {
    public static Date convertTimeFromEpoch(BigDecimal epochTime){
        if(epochTime == null) return null;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
        Date dateTime = new Date(epochTime.longValue());


        return (dateTime);
    }

    public static void log(String path, String s, boolean appended) throws IOException {
        try {
            File file = new File(path);
            FileWriter fw = new FileWriter(file, appended);
            BufferedWriter bw = new BufferedWriter(fw);

            bw.write(s + "\n");

            bw.close();
            fw.close();
        }catch (Exception e){

        }
    }

    public static String getBetween(String s, String sd, String ed){
        int spos = s.indexOf(sd);
        int epos = -1;
        if(spos >= 0){
            epos = s.indexOf(ed, spos + sd.length() + 1);
            if(epos >= 0){
                return s.substring(spos + sd.length(), epos);
            }
            else{
                return "";
            }
        }
        else{
            return "";
        }
    }

}
