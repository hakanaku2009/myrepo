package utils;

import com.couchbase.client.java.Bucket;
import com.couchbase.client.java.Cluster;
import com.couchbase.client.java.CouchbaseCluster;
import com.couchbase.client.java.env.CouchbaseEnvironment;
import com.couchbase.client.java.env.DefaultCouchbaseEnvironment;
import com.couchbase.client.java.query.*;

public class CouchbaseManager {
    Cluster cluster = null;
    String cbHost = "";
    String cbUser = "";
    String cbPasswd = "";

    public CouchbaseManager(String host, String user, String pass){
        cbHost = host;
        cbUser = user;
        cbPasswd = pass;
        getConnection();
    }

    public void getConnection(){
        if(cluster == null){
            CouchbaseEnvironment env = DefaultCouchbaseEnvironment.builder().connectTimeout(120000).build();

            cluster = CouchbaseCluster.create(env, cbHost);
            cluster.authenticate(cbUser, cbPasswd);
        }
    }

    public int queryCount(String bucketName, String sql){
        getConnection();
        Bucket bucket = cluster.openBucket(bucketName);
        int count = 0;

        Statement query = N1qlQuery.simple(sql).statement();
        N1qlQueryResult result = bucket.query(query);

        if (result.finalSuccess()){
            count = (int) result.allRows().get(0).value().get("$1");
        }
        return count;
    }

    public static void main(String[] args) {
        CouchbaseManager cbManager = new CouchbaseManager("10.145.198.104", "Administrator", "Prudential01");
        String typekey = "vn.com.prudential.agentapp.entity.DeviceToken";
        System.out.println(cbManager.queryCount("agentapp_uat", "select count(*) from agentapp_uat " +
                "where typekey = '"+ typekey +"'"));
    }


}
