package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import models.common.Payload;
import utils.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "Candidate")
public class Candidate implements Serializable{
	public Candidate(){}

	@Id
	@Column(name = "key")
	@JsonProperty("key")
	@Getter
	@Setter
	public String key;

	@Column(name = "cas")
	@JsonProperty("cas")
	@Getter
	@Setter
	public String cas;

	@Column(name = "bySeqNo")
	@JsonProperty("bySeqNo")
	@Getter
	@Setter
	public BigDecimal bySeqNo;

	@Column(name = "revSeqNo")
	@JsonProperty("revSeqNo")
	@Getter
	@Setter
	public BigDecimal revSeqNo;

	@Column(name = "id")
	@JsonProperty("id")
	@Getter
	@Setter
	public String id;

	@Column(name = "name")
	@JsonProperty("name")
	@Getter
	@Setter
	public String name;

	@Column(name = "phone")
	@JsonProperty("phone")
	@Getter
	@Setter
	public String phone;

	@Column(name = "registrationDate")
	@Getter
	@Setter
	public Date registrationDate_temp;

	@Transient
	@JsonProperty("registrationDate")
	@Getter
	public String registrationDate;

	public void setRegistrationDate(String registrationDate) throws Exception{
		if(registrationDate != null && !registrationDate.trim().equals("")) {
			this.registrationDate_temp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX").parse(registrationDate);
			this.registrationDate = registrationDate;
		}
}

	@Column(name = "typekey")
	@JsonProperty("typekey")
	@Getter
	@Setter
	public String typekey;

	public void save(Session session, Payload payload){
		Transaction transaction = session.beginTransaction();
		if(payload.event.trim().toLowerCase().equals("mutation")) {
			session.merge(this);
		}
		else{
			if(payload.event.trim().toLowerCase().equals("deletion") ||
					payload.event.trim().toLowerCase().equals("expiration")){
				session.delete(session.merge(this));
			}
		}
		transaction.commit();
	}
}