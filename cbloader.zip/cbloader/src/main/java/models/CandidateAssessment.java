package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import models.common.Payload;
import utils.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "CandidateAssessment")
public class CandidateAssessment implements Serializable{
	public CandidateAssessment(){}

	@Id
	@Column(name = "key")
	@JsonProperty("key")
	@Getter
	@Setter
	public String key;

	@Column(name = "cas")
	@JsonProperty("cas")
	@Getter
	@Setter
	public String cas;

	@Column(name = "bySeqNo")
	@JsonProperty("bySeqNo")
	@Getter
	@Setter
	public BigDecimal bySeqNo;

	@Column(name = "revSeqNo")
	@JsonProperty("revSeqNo")
	@Getter
	@Setter
	public BigDecimal revSeqNo;

	@Column(name = "AGCLNAME")
	@JsonProperty("AGCLNAME")
	@Getter
	@Setter
	public String AGCLNAME;

	@Column(name = "LastDTEcohortTo")
	@Getter
	@Setter
	public Date LastDTEcohortTo_temp;

	@Transient
	@JsonProperty("LastDTEcohortTo")
	@Getter
	public String LastDTEcohortTo;

	public void setLastDTEcohortTo(String ldte) throws Exception{
		if(ldte != null && !ldte.trim().equals("")) {
			this.LastDTEcohortTo_temp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX").parse(ldte);
			this.LastDTEcohortTo = ldte;
		}
	}

	@Column(name = "LastDTEupdated")
	@Getter
	@Setter
	public Date LastDTEupdated_temp;

	@Transient
	@JsonProperty("LastDTEupdated")
	@Getter
	public String LastDTEupdated;

	public void setLastDTEupdated(String ldte) throws Exception{
		if(ldte != null && !ldte.trim().equals("")) {
			this.LastDTEupdated_temp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX").parse(ldte);
			this.LastDTEupdated = ldte;
		}
	}

	@Column(name = "agentName")
	@JsonProperty("agentName")
	@Getter
	@Setter
	public String agentName;

	@Column(name = "assessByDesc")
	@JsonProperty("assessByDesc")
	@Getter
	@Setter
	public String assessByDesc;

	@Column(name = "assessByRole")
	@JsonProperty("assessByRole")
	@Getter
	@Setter
	public String assessByRole;

	@Column(name = "assessDate")
	@Getter
	@Setter
	public Date assessDate_temp;

	@Transient
	@JsonProperty("assessDate")
	@Getter
	public String assessDate;

	public void setAssessDate(String ad) throws Exception{
		if(ad != null && !ad.trim().equals("")) {
			this.assessDate_temp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX").parse(ad);
			this.assessDate = ad;
		}
	}

	@Column(name = "candidateID")
	@JsonProperty("candidateID")
	@Getter
	@Setter
	public String candidateID;

	@Column(name = "createdDate")
	@Getter
	@Setter
	public Date createdDate_temp;

	@Transient
	@JsonProperty("createdDate")
	@Getter
	public String createdDate;

	public void setCreatedDate(String cd) throws Exception{
		if(cd != null && !cd.trim().equals("")) {
			this.createdDate_temp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX").parse(cd);
			this.createdDate = cd;
		}
	}

	@Transient
	@JsonProperty("generalReviews")
	@Getter
	public GeneralReviews generalReviews;

	public void setGeneralReviews(GeneralReviews reviews){
		if(reviews != null) {
			this.generalReviews = reviews;
			this.appearanceOrHealth = reviews.appearanceOrHealth;
			this.attitude = reviews.attitude;
			this.commitment = reviews.commitment;
			this.communicationSkill = reviews.communicationSkill;
			this.socialRelationship = reviews.socialRelationship;
			this.technicalAbility = reviews.technicalAbility;
		}
	}

	@Column(name = "appearanceOrHealth")
	@Getter
	@Setter
	public String appearanceOrHealth;

	@Column(name = "attitude")
	@Getter
	@Setter
	public String attitude;

	@Column(name = "commitment")
	@Getter
	@Setter
	public String commitment;

	@Column(name = "communicationSkill")
	@Getter
	@Setter
	public String communicationSkill;

	@Column(name = "socialRelationship")
	@Getter
	@Setter
	public String socialRelationship;

	@Column(name = "technicalAbility")
	@Getter
	@Setter
	public String technicalAbility;

	@Column(name = "idNumber")
	@JsonProperty("idNumber")
	@Getter
	@Setter
	public String idNumber;

	@Column(name = "isBDMAssess")
	@JsonProperty("isBDMAssess")
	@Getter
	@Setter
	public String isBDMAssess;

	@Column(name = "leaderCodeDesc")
	@JsonProperty("leaderCodeDesc")
	@Getter
	@Setter
	public String leaderCodeDesc;

	@Column(name = "potentialCustomer")
	@JsonProperty("potentialCustomer")
	@Getter
	@Setter
	public String potentialCustomer;

	@Column(name = "reAssess")
	@JsonProperty("reAssess")
	@Getter
	@Setter
	public String reAssess;

	@Column(name = "reAssessDate")
	@Getter
	@Setter
	public Date reAssessDate_temp;

	@Transient
	@JsonProperty("reAssessDate")
	@Getter
	public String reAssessDate;

	public void setReAssessDate(String rad) throws Exception{
		if(rad != null && !rad.trim().equals("")) {
			this.reAssessDate_temp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX").parse(rad);
			this.reAssessDate = rad;
		}
	}

	@Transient
	@JsonProperty("recruitmentStandards")
	@Getter
	RecruitmentStandards recruitmentStandards;

	public void setRecruitmentStandards(RecruitmentStandards rs){
		if(rs != null) {
			this.recruitmentStandards = rs;
			this.isAge24To34 = rs.isAge24To34;
			this.isExperiencedWorking = rs.isExperiencedWorking;
			this.isGraduatedHighSchool = rs.isGraduatedHighSchool;
			this.isMarried = rs.isMarried;
			this.isPotentialCustomerOver20 = rs.isPotentialCustomerOver20;
		}
	}

	@Column(name = "isAge24To34")
	@Getter
	@Setter
	public String isAge24To34;

	@Column(name = "isExperiencedWorking")
	@Getter
	@Setter
	public String isExperiencedWorking;

	@Column(name = "isGraduatedHighSchool")
	@Getter
	@Setter
	public String isGraduatedHighSchool;

	@Column(name = "isMarried")
	@Getter
	@Setter
	public String isMarried;

	@Column(name = "isPotentialCustomerOver20")
	@Getter
	@Setter
	public String isPotentialCustomerOver20;

	@Column(name = "status")
	@JsonProperty("status")
	@Getter
	@Setter
	public String status;

	@Column(name = "totalScore")
	@JsonProperty("totalScore")
	@Getter
	@Setter
	public String totalScore;

	@Column(name = "typekey")
	@JsonProperty("typekey")
	@Getter
	@Setter
	public String typekey;

	@Column(name = "unitCode")
	@JsonProperty("unitCode")
	@Getter
	@Setter
	public String unitCode;

	public void save(Session session, Payload payload){
		Transaction transaction = session.beginTransaction();
		if(payload.event.trim().toLowerCase().equals("mutation")) {
			session.merge(this);
		}
		else{
			if(payload.event.trim().toLowerCase().equals("deletion") ||
					payload.event.trim().toLowerCase().equals("expiration")){
				session.delete(session.merge(this));
			}
		}
		transaction.commit();
	}
}