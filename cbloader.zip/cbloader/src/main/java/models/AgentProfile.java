package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import models.common.Payload;
import utils.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "AgentProfile")
public class AgentProfile implements Serializable{
	public AgentProfile(){}

	@Id
	@Column(name = "key")
	@JsonProperty("key")
	@Getter
	@Setter
	public String key;

	@Column(name = "cas")
	@JsonProperty("cas")
	@Getter
	@Setter
	public String cas;

	@Column(name = "bySeqNo")
	@JsonProperty("bySeqNo")
	@Getter
	@Setter
	public BigDecimal bySeqNo;

	@Column(name = "revSeqNo")
	@JsonProperty("revSeqNo")
	@Getter
	@Setter
	public BigDecimal revSeqNo;

	@Column(name = "agentCode")
	@JsonProperty("agentCode")
	@Getter
	@Setter
	public String agentCode;

//	@Column(name = "clientAccessKey")
//	@JsonProperty("clientAccessKey")
//	@Getter
//	@Setter
//	public String clientAccessKey;

	@Column(name = "dob")
	@JsonProperty("dob")
	@Getter
	@Setter
	public String dob;

	@Column(name = "email")
	@JsonProperty("email")
	@Getter
	@Setter
	public String email;

	@Column(name = "manager")
	@JsonProperty("manager")
	@Getter
	@Setter
	public String manager;

	@Column(name = "mobile")
	@JsonProperty("mobile")
	@Getter
	@Setter
	public String mobile;

	@Column(name = "name")
	@JsonProperty("name")
	@Getter
	@Setter
	public String name;

	@Column(name = "position")
	@JsonProperty("position")
	@Getter
	@Setter
	public String position;

	@Column(name = "title")
	@JsonProperty("title")
	@Getter
	@Setter
	public String title;

	@Column(name = "typekey")
	@JsonProperty("typekey")
	@Getter
	@Setter
	public String typekey;

	public void save(Session session, Payload payload){
		Transaction transaction = session.beginTransaction();
		if(payload.event.trim().toLowerCase().equals("mutation")) {
			session.merge(this);
		}
		else{
			if(payload.event.trim().toLowerCase().equals("deletion") ||
					payload.event.trim().toLowerCase().equals("expiration")){
				session.delete(session.merge(this));
			}
		}
		transaction.commit();
	}
}