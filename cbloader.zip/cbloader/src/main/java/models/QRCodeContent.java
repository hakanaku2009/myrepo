package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import models.common.Payload;
import utils.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "QRCodeContent")
public class QRCodeContent implements Serializable{
	public QRCodeContent(){}

	@Id
	@Column(name = "key")
	@JsonProperty("key")
	@Getter
	@Setter
	public String key;

	@Column(name = "cas")
	@JsonProperty("cas")
	@Getter
	@Setter
	public String cas;

	@Column(name = "bySeqNo")
	@JsonProperty("bySeqNo")
	@Getter
	@Setter
	public BigDecimal bySeqNo;

	@Column(name = "revSeqNo")
	@JsonProperty("revSeqNo")
	@Getter
	@Setter
	public BigDecimal revSeqNo;

	@Column(name = "activityCode")
	@JsonProperty("activityCode")
	@Getter
	@Setter
	public String activityCode;

//	@Column(name = "clientAccessKey")
//	@JsonProperty("clientAccessKey")
//	@Getter
//	@Setter
//	public String clientAccessKey;

//	@Column(name = "content")
//	@JsonProperty("content")
//	@Getter
//	@Setter
//	public String content;

	@Column(name = "createdAt")
	@Getter
	@Setter
	public Date createdAt_temp;

	@Transient
	@JsonProperty("createdAt")
	@Getter
	public BigDecimal createdAt;

	public void setCreatedAt(BigDecimal createdAt) {
		if(createdAt != null) {
			this.createdAt_temp = Utils.convertTimeFromEpoch(createdAt);
			this.createdAt = createdAt;
		}
}

	@Column(name = "idCounter")
	@JsonProperty("idCounter")
	@Getter
	@Setter
	public String idCounter;

	@Column(name = "idPrefix")
	@JsonProperty("idPrefix")
	@Getter
	@Setter
	public String idPrefix;

	@Column(name = "score")
	@JsonProperty("score")
	@Getter
	@Setter
	public BigDecimal score;

	@Column(name = "typekey")
	@JsonProperty("typekey")
	@Getter
	@Setter
	public String typekey;

	@Column(name = "updatedAt")
	@Getter
	@Setter
	public Date updatedAt_temp;

	@Transient
	@JsonProperty("updatedAt")
	@Getter
	public BigDecimal updatedAt;

	public void setUpdatedAt(BigDecimal updatedAt) {
		if(updatedAt != null) {
			this.updatedAt_temp = Utils.convertTimeFromEpoch(updatedAt);
			this.updatedAt = updatedAt;
		}
}

	public void save(Session session, Payload payload){
		Transaction transaction = session.beginTransaction();
		if(payload.event.trim().toLowerCase().equals("mutation")) {
			session.merge(this);
		}
		else{
			if(payload.event.trim().toLowerCase().equals("deletion") ||
					payload.event.trim().toLowerCase().equals("expiration")){
				session.delete(session.merge(this));
			}
		}
		transaction.commit();
	}
}