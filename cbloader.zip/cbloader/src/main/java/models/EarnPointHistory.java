package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import models.common.Payload;
import utils.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "EarnPointHistory")
public class EarnPointHistory implements Serializable{
	public EarnPointHistory(){}

	@Id
	@Column(name = "key")
	@JsonProperty("key")
	@Getter
	@Setter
	public String key;

	@Column(name = "cas")
	@JsonProperty("cas")
	@Getter
	@Setter
	public String cas;

	@Column(name = "bySeqNo")
	@JsonProperty("bySeqNo")
	@Getter
	@Setter
	public BigDecimal bySeqNo;

	@Column(name = "revSeqNo")
	@JsonProperty("revSeqNo")
	@Getter
	@Setter
	public BigDecimal revSeqNo;

	@Column(name = "agentCode")
	@JsonProperty("agentCode")
	@Getter
	@Setter
	public String agentCode;

//	@Column(name = "clientAccessKey")
//	@JsonProperty("clientAccessKey")
//	@Getter
//	@Setter
//	public String clientAccessKey;

	@Column(name = "createdDate")
	@Getter
	@Setter
	public Date createdDate_temp;

	@Transient
	@JsonProperty("createdDate")
	@Getter
	public BigDecimal createdDate;

	public void setCreatedDate(BigDecimal createdDate) {
		if(createdDate != null) {
			this.createdDate_temp = Utils.convertTimeFromEpoch(createdDate);
			this.createdDate = createdDate;
		}
}

	@Column(name = "idCounter")
	@JsonProperty("idCounter")
	@Getter
	@Setter
	public BigDecimal idCounter;

	@Column(name = "idPrefix")
	@JsonProperty("idPrefix")
	@Getter
	@Setter
	public String idPrefix;

	@Column(name = "mainType")
	@JsonProperty("mainType")
	@Getter
	@Setter
	public BigDecimal mainType;

	@Column(name = "point")
	@JsonProperty("point")
	@Getter
	@Setter
	public BigDecimal point;

	@Transient
	@JsonProperty("sync")
	@Getter
	public Sync sync;

	public void setSync(Sync sy) throws Exception {
		if(sy != null) {
			this.sync = sy;
			this.sync_channel = sync.getChannel();
			this.sync_accessChannel = sync.getAccessChannel();
			this.sync_accessUser = sync.getAccessUser();
			this.sync_requireAdmin = sync.getRequireAdmin();
			this.sync_requireUser = sync.getRequireUser();
			this.sync_requireAccess = sync.getRequireAccess();
			this.sync_expiry = sync.getExpiry();
		}
	}

	@Column(name = "sync_channel")
	@Getter
	@Setter
	public String sync_channel;

	@Column(name = "sync_accessChannel")
	@Getter
	@Setter
	public String sync_accessChannel;

	@Column(name = "sync_accessUser")
	@Getter
	@Setter
	public String sync_accessUser;

	@Column(name = "sync_requireAdmin")
	@Getter
	@Setter
	public String sync_requireAdmin;

	@Column(name = "sync_requireUser")
	@Getter
	@Setter
	public String sync_requireUser;

	@Column(name = "sync_requireAccess")
	@Getter
	@Setter
	public String sync_requireAccess;

	@Column(name = "sync_expiry")
	@Getter
	@Setter
	public Date sync_expiry;

	@Column(name = "title")
	@JsonProperty("title")
	@Getter
	@Setter
	public String title;

	@Column(name = "type")
	@JsonProperty("type")
	@Getter
	@Setter
	public BigDecimal type;

	@Column(name = "typekey")
	@JsonProperty("typekey")
	@Getter
	@Setter
	public String typekey;

	@Column(name = "rewardId")
	@JsonProperty("rewardId")
	@Getter
	@Setter
	public String rewardId;

	public void save(Session session, Payload payload){
		Transaction transaction = session.beginTransaction();
		if(payload.event.trim().toLowerCase().equals("mutation")) {
			session.merge(this);
		}
		else{
			if(payload.event.trim().toLowerCase().equals("deletion") ||
					payload.event.trim().toLowerCase().equals("expiration")){
				session.delete(session.merge(this));
			}
		}
		transaction.commit();
	}
}