package models;
import com.fasterxml.jackson.annotation.*;

import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OTPMethod implements Serializable {
    @JsonProperty("tag")
    public String tag;

    @JsonProperty("value")
    public String value;
}
