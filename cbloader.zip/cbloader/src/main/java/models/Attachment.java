package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import models.common.Payload;
import utils.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "Attachment")
public class Attachment implements Serializable{
	public Attachment(){}

	@Id
	@Column(name = "key")
	@JsonProperty("key")
	@Getter
	@Setter
	public String key;

	@Column(name = "cas")
	@JsonProperty("cas")
	@Getter
	@Setter
	public String cas;

	@Column(name = "bySeqNo")
	@JsonProperty("bySeqNo")
	@Getter
	@Setter
	public BigDecimal bySeqNo;

	@Column(name = "revSeqNo")
	@JsonProperty("revSeqNo")
	@Getter
	@Setter
	public BigDecimal revSeqNo;

	@Column(name = "agentCodeSendTest")
	@JsonProperty("agentCodeSendTest")
	@Getter
	@Setter
	public String agentCodeSendTest;

	@Column(name = "colA")
	@JsonProperty("colA")
	@Getter
	@Setter
	public String colA;

	@Column(name = "colB")
	@JsonProperty("colB")
	@Getter
	@Setter
	public String colB;

	@Column(name = "colC")
	@JsonProperty("colC")
	@Getter
	@Setter
	public String colC;

	@Column(name = "colD")
	@JsonProperty("colD")
	@Getter
	@Setter
	public String colD;

	@Column(name = "colE")
	@JsonProperty("colE")
	@Getter
	@Setter
	public String colE;

	@Column(name = "colF")
	@JsonProperty("colF")
	@Getter
	@Setter
	public String colF;

	@Column(name = "colG")
	@JsonProperty("colG")
	@Getter
	@Setter
	public String colG;

	@Column(name = "colH")
	@JsonProperty("colH")
	@Getter
	@Setter
	public String colH;

	@Column(name = "colI")
	@JsonProperty("colI")
	@Getter
	@Setter
	public String colI;

	@Column(name = "colJ")
	@JsonProperty("colJ")
	@Getter
	@Setter
	public String colJ;

//	@Column(name = "content")
//	@JsonProperty("content")
//	@Getter
//	@Setter
//	public String content;

	@Column(name = "createdDate")
	@Getter
	@Setter
	public Date createdDate_temp;

	@Transient
	@JsonProperty("createdDate")
	@Getter
	public BigDecimal createdDate;

	public void setCreatedDate(BigDecimal createdDate) {
		if(createdDate != null) {
			this.createdDate_temp = Utils.convertTimeFromEpoch(createdDate);
			this.createdDate = createdDate;
		}
}

//	@Column(name = "footer")
//	@JsonProperty("footer")
//	@Getter
//	@Setter
//	public String footer;
//
//	@Column(name = "header")
//	@JsonProperty("header")
//	@Getter
//	@Setter
//	public String header;

	@Column(name = "idCounter")
	@JsonProperty("idCounter")
	@Getter
	@Setter
	public String idCounter;

	@Column(name = "idPrefix")
	@JsonProperty("idPrefix")
	@Getter
	@Setter
	public String idPrefix;

	@Column(name = "isSend")
	@JsonProperty("isSend")
	@Getter
	@Setter
	public String isSend;

	@Column(name = "isTesting")
	@JsonProperty("isTesting")
	@Getter
	@Setter
	public String isTesting;

	@Column(name = "phoneNumber")
	@JsonProperty("phoneNumber")
	@Getter
	@Setter
	public String phoneNumber;

	@Column(name = "referralType")
	@JsonProperty("referralType")
	@Getter
	@Setter
	public String referralType;

	@Column(name = "sendDate")
	@Getter
	@Setter
	public Date sendDate_temp;

	@Transient
	@JsonProperty("sentDate")
	@Getter
	public BigDecimal sendDate;

	public void setSendDate(BigDecimal sendDate) {
		if(sendDate != null) {
			this.sendDate_temp = Utils.convertTimeFromEpoch(sendDate);
			this.sendDate = sendDate;
		}
	}

	@Column(name = "type")
	@JsonProperty("type")
	@Getter
	@Setter
	public String type;

	@Column(name = "typekey")
	@JsonProperty("typekey")
	@Getter
	@Setter
	public String typekey;

	@Column(name = "messageDetailId")
	@JsonProperty("messageDetailId")
	@Getter
	@Setter
	public String messageDetailId;

	@Column(name = "isRegister")
	@JsonProperty("isRegister")
	@Getter
	@Setter
	public String isRegister;

	public void save(Session session, Payload payload){
		Transaction transaction = session.beginTransaction();
		if(payload.event.trim().toLowerCase().equals("mutation")) {
			session.merge(this);
		}
		else{
			if(payload.event.trim().toLowerCase().equals("deletion") ||
					payload.event.trim().toLowerCase().equals("expiration")){
				session.delete(session.merge(this));
			}
		}
		transaction.commit();
	}
}