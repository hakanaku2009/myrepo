package models;

import com.fasterxml.jackson.annotation.*;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import models.common.Payload;
import utils.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "Livestream")
public class Livestream implements Serializable {
    public Livestream(){}

    @Id
    @Column(name = "key")
    @JsonProperty("key")
    @Getter
    @Setter
    public String key;

    @Column(name = "cas")
    @JsonProperty("cas")
    @Getter
    @Setter
    public String cas;

    @Column(name = "bySeqNo")
    @JsonProperty("bySeqNo")
    @Getter
    @Setter
    public BigDecimal bySeqNo;

    @Column(name = "revSeqNo")
    @JsonProperty("revSeqNo")
    @Getter
    @Setter
    public BigDecimal revSeqNo;

    @Column(name = "allUser")
    @JsonProperty("allUser")
    @Getter
    @Setter
    public String allUser;

    @Column(name = "bannerImg")
    @JsonProperty("bannerImg")
    @Getter
    @Setter
    public String bannerImg;

    @Column(name = "createdDate")
    @Getter
    @Setter
    public Date createdDate_temp;

    @Transient
    @JsonProperty("createdDate")
    @Getter
    public String createdDate;

    public void setCreatedDate(String createdDate) throws Exception {
        if(createdDate != null && !createdDate.trim().equals("")) {
            this.createdDate_temp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX").parse(createdDate);
            this.createdDate = createdDate;
        }
    }

    @Column(name = "createdTime")
    @Getter
    @Setter
    public Date createdTime_temp;

    @Transient
    @JsonProperty("createdTime")
    @Getter
    public BigDecimal createdTime;

    public void setCreatedTime(BigDecimal createdTime) {
        if(createdTime != null) {
            this.createdTime_temp = Utils.convertTimeFromEpoch(createdTime);
            this.createdTime = createdTime;
        }
    }

    @Column(name = "description")
    @JsonProperty("description")
    @Getter
    @Setter
    public String description;

    @Column(name = "eventImg")
    @JsonProperty("eventImg")
    @Getter
    @Setter
    public String eventImg;

    @Column(name = "fileName")
    @JsonProperty("fileName")
    @Getter
    @Setter
    public String fileName;

    @Column(name = "groupOfUser")
    @JsonProperty("groupOfUser")
    @Getter
    @Setter
    public String groupOfUser;

    @Column(name = "id")
    @JsonProperty("id")
    @Getter
    @Setter
    public String id;

    @Column(name = "idCounter")
    @JsonProperty("idCounter")
    @Getter
    @Setter
    public BigDecimal idCounter;

    @Column(name = "idPrefix")
    @JsonProperty("idPrefix")
    @Getter
    @Setter
    public String idPrefix;

    @Column(name = "includeSA")
    @JsonProperty("includeSA")
    @Getter
    @Setter
    public String includeSA;

    @Transient
    @JsonProperty("interaction")
    @Getter
    Interation interation;
    public void setInteration(Interation interac){
        if(interac != null) {
            interaction_comment = interac.comment;
            interaction_like = interac.like;
            interac_viewStreamed_count = interac.viewStreamed.count;
            interac_viewStreamed_duration = interac.viewStreamed.duration;
            interac_viewStreaming_count = interac.viewStreaming.count;
            interac_viewStreaming_duration = interac.viewStreaming.duration;
        }
    }

    @Column(name = "interaction_comment")
    @Getter
    @Setter
    public BigDecimal interaction_comment;

    @Column(name = "interaction_like")
    @Getter
    @Setter
    public BigDecimal interaction_like;

    @Column(name = "interac_viewStreamed_count")
    @Getter
    @Setter
    public BigDecimal interac_viewStreamed_count;

    @Column(name = "interac_viewStreamed_duration")
    @Getter
    @Setter
    public BigDecimal interac_viewStreamed_duration;

    @Column(name = "interac_viewStreaming_count")
    @Getter
    @Setter
    public BigDecimal interac_viewStreaming_count;

    @Column(name = "interac_viewStreaming_duration")
    @Getter
    @Setter
    public BigDecimal interac_viewStreaming_duration;

    @Column(name = "name")
    @JsonProperty("name")
    @Getter
    @Setter
    public String name;

    @Column(name = "notifyStatus")
    @JsonProperty("notifyStatus")
    @Getter
    @Setter
    public String notifyStatus;

    @Column(name = "startDate")
    @Getter
    @Setter
    public Date startDate_temp;

    @Transient
    @JsonProperty("startDate")
    @Getter
    public String startDate;

    public void setStartDate(String startDate) throws Exception {
        if(startDate != null && !startDate.trim().equals("")) {
            this.startDate_temp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX").parse(startDate);
            this.startDate = startDate;
        }
    }

    @Column(name = "startTime")
    @Getter
    @Setter
    public Date startTime_temp;

    @Transient
    @JsonProperty("startTime")
    @Getter
    public BigDecimal startTime;

    public void setStartTime(BigDecimal startTime) {
        if(startTime != null) {
            this.startTime_temp = Utils.convertTimeFromEpoch(startTime);
            this.startTime = startTime;
        }
    }

    @Column(name = "status")
    @JsonProperty("status")
    @Getter
    @Setter
    public String status;

    @Column(name = "streamLink")
    @JsonProperty("streamLink")
    @Getter
    @Setter
    public String streamLink;

    @Transient
    @JsonProperty("sync")
    @Getter
    public Sync sync;

    public void setSync(Sync sy) throws Exception {
        if(sy != null) {
            this.sync = sy;
            this.sync_channel = sync.getChannel();
            this.sync_accessChannel = sync.getAccessChannel();
            this.sync_accessUser = sync.getAccessUser();
            this.sync_requireAdmin = sync.getRequireAdmin();
            this.sync_requireUser = sync.getRequireUser();
            this.sync_requireAccess = sync.getRequireAccess();
            this.sync_expiry = sync.getExpiry();
        }
    }

    @Column(name = "sync_channel")
    @Getter
    @Setter
    public String sync_channel;

    @Column(name = "sync_accessChannel")
    @Getter
    @Setter
    public String sync_accessChannel;

    @Column(name = "sync_accessUser")
    @Getter
    @Setter
    public String sync_accessUser;

    @Column(name = "sync_requireAdmin")
    @Getter
    @Setter
    public String sync_requireAdmin;

    @Column(name = "sync_requireUser")
    @Getter
    @Setter
    public String sync_requireUser;

    @Column(name = "sync_requireAccess")
    @Getter
    @Setter
    public String sync_requireAccess;

    @Column(name = "sync_expiry")
    @Getter
    @Setter
    public Date sync_expiry;

    @Column(name = "typekey")
    @JsonProperty("typekey")
    @Getter
    @Setter
    public String typekey;

    @Column(name = "updateDate")
    @Getter
    @Setter
    public Date updateDate_temp;

    @Transient
    @JsonProperty("updateDate")
    @Getter
    public BigDecimal updateDate;

    public void setUpdateDate(BigDecimal updateDate) {
        if(updateDate != null) {
            this.updateDate_temp = Utils.convertTimeFromEpoch(updateDate);
            this.updateDate = updateDate;
        }
    }

    public void save(Session session, Payload payload){
        Transaction transaction = session.beginTransaction();
        if(payload.event.trim().toLowerCase().equals("mutation")) {
            session.merge(this);
        }
        else{
            if(payload.event.trim().toLowerCase().equals("deletion") ||
                    payload.event.trim().toLowerCase().equals("expiration")){
                session.delete(session.merge(this));
            }
        }
        transaction.commit();
    }
}