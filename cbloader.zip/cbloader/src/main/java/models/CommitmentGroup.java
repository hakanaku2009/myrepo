package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import models.common.Payload;
import utils.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "CommitmentGroup")
public class CommitmentGroup implements Serializable{
	public CommitmentGroup(){}

	@Id
	@Column(name = "key")
	@JsonProperty("key")
	@Getter
	@Setter
	public String key;

	@Column(name = "cas")
	@JsonProperty("cas")
	@Getter
	@Setter
	public String cas;

	@Column(name = "bySeqNo")
	@JsonProperty("bySeqNo")
	@Getter
	@Setter
	public BigDecimal bySeqNo;

	@Column(name = "revSeqNo")
	@JsonProperty("revSeqNo")
	@Getter
	@Setter
	public BigDecimal revSeqNo;

	@Column(name = "agentCode")
	@JsonProperty("agentCode")
	@Getter
	@Setter
	public String agentCode;

	@Column(name = "apeTotalActual")
	@JsonProperty("apeTotalActual")
	@Getter
	@Setter
	public BigDecimal apeTotalActual;

	@Column(name = "apeTotalCommit")
	@JsonProperty("apeTotalCommit")
	@Getter
	@Setter
	public BigDecimal apeTotalCommit;

	@Column(name = "approveBy")
	@JsonProperty("approvedBy")
	@Getter
	@Setter
	public String approveBy;

	@Column(name = "approveDate")
	@Getter
	@Setter
	public Date approveDate_temp;

	@Transient
	@JsonProperty("approvedDate")
	@Getter
	public BigDecimal approveDate;

	public void setApproveDate(BigDecimal approveDate) {
		if(approveDate != null) {
			this.approveDate_temp = Utils.convertTimeFromEpoch(approveDate);
			this.approveDate = approveDate;
		}
	}

	@Column(name = "bopParticipant")
	@JsonProperty("bopParticipant")
	@Getter
	@Setter
	public BigDecimal bopParticipant;

	@Column(name = "committedDate")
	@Getter
	@Setter
	public Date committedDate_temp;

	@Transient
	@JsonProperty("committedDate")
	@Getter
	public BigDecimal committedDate;

	public void setCommittedDate(BigDecimal committedDate) {
		if(committedDate != null) {
			this.committedDate_temp = Utils.convertTimeFromEpoch(committedDate);
			this.committedDate = committedDate;
		}
}

	@Column(name = "contractExpect")
	@JsonProperty("contractExpect")
	@Getter
	@Setter
	public BigDecimal contractExpect;

	@Column(name = "createdDate")
	@Getter
	@Setter
	public Date createdDate_temp;

	@Transient
	@JsonProperty("createdDate")
	@Getter
	public BigDecimal createdDate;

	public void setCreatedDate(BigDecimal createdDate) {
		if(createdDate != null) {
			this.createdDate_temp = Utils.convertTimeFromEpoch(createdDate);
			this.createdDate = createdDate;
		}
}

	@Column(name = "customerCommit")
	@JsonProperty("customerCommit")
	@Getter
	@Setter
	public BigDecimal customerCommit;

	@Column(name = "idCounter")
	@JsonProperty("idCounter")
	@Getter
	@Setter
	public BigDecimal idCounter;

	@Column(name = "idPrefix")
	@JsonProperty("idPrefix")
	@Getter
	@Setter
	public String idPrefix;

	@Column(name = "newRecruit")
	@JsonProperty("newRecruit")
	@Getter
	@Setter
	public BigDecimal newRecruit;

	@Column(name = "newTrainee")
	@JsonProperty("newTrainee")
	@Getter
	@Setter
	public BigDecimal newTrainee;

	@Column(name = "note")
	@JsonProperty("note")
	@Getter
	@Setter
	public String note;

	@Column(name = "officeCode")
	@JsonProperty("officeCode")
	@Getter
	@Setter
	public String officeCode;

	@Column(name = "reason")
	@JsonProperty("reason")
	@Getter
	@Setter
	public String reason;

	@Column(name = "rejectedBy")
	@JsonProperty("rejectedBy")
	@Getter
	@Setter
	public String rejectedBy;

	@Column(name = "rejectedDate")
	@Getter
	@Setter
	public Date rejectedDate_temp;

	@Transient
	@JsonProperty("rejectedDate")
	@Getter
	public BigDecimal rejectedDate;

	public void setRejectedDate(BigDecimal rejectedDate) {
		if(rejectedDate != null) {
			this.rejectedDate_temp = Utils.convertTimeFromEpoch(rejectedDate);
			this.rejectedDate = rejectedDate;
		}
	}

	@Column(name = "status")
	@JsonProperty("status")
	@Getter
	@Setter
	public String status;

	@Column(name = "totalTraineeApe")
	@JsonProperty("totalTraineeApe")
	@Getter
	@Setter
	public BigDecimal totalTraineeApe;

	@Column(name = "totalTraineeContract")
	@JsonProperty("totalTraineeContract")
	@Getter
	@Setter
	public BigDecimal totalTraineeContract;

	@Column(name = "typekey")
	@JsonProperty("typekey")
	@Getter
	@Setter
	public String typekey;

	@Column(name = "unitCode")
	@JsonProperty("unitCode")
	@Getter
	@Setter
	public String unitCode;

	@Column(name = "updateDate")
	@Getter
	@Setter
	public Date updateDate_temp;

	@Transient
	@JsonProperty("updateDate")
	@Getter
	public BigDecimal updateDate;

	public void setUpdateDate(BigDecimal updateDate) {
		if(updateDate != null) {
			this.updateDate_temp = Utils.convertTimeFromEpoch(updateDate);
			this.updateDate = updateDate;
		}
	}

	public void save(Session session, Payload payload){
		Transaction transaction = session.beginTransaction();
		if(payload.event.trim().toLowerCase().equals("mutation")) {
			session.merge(this);
		}
		else{
			if(payload.event.trim().toLowerCase().equals("deletion") ||
					payload.event.trim().toLowerCase().equals("expiration")){
				session.delete(session.merge(this));
			}
		}
		transaction.commit();
	}
}