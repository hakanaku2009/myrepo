package models;

import com.fasterxml.jackson.annotation.*;

import javax.swing.text.View;
import java.io.Serializable;
import java.math.BigDecimal;


@JsonIgnoreProperties(ignoreUnknown = true)
public class Interation implements Serializable{
    @JsonProperty("comment")
    public BigDecimal comment;
    @JsonProperty("like")
    public BigDecimal like;
    @JsonProperty("viewStreamed")
    public ViewStream viewStreamed;
    @JsonProperty("viewStreaming")
    public ViewStream viewStreaming;

}
