package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import models.common.Payload;
import utils.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "Message")
public class Message implements Serializable{
	public Message(){}

	@Id
	@Column(name = "key")
	@JsonProperty("key")
	@Getter
	@Setter
	public String key;

	@Column(name = "cas")
	@JsonProperty("cas")
	@Getter
	@Setter
	public String cas;

	@Column(name = "bySeqNo")
	@JsonProperty("bySeqNo")
	@Getter
	@Setter
	public BigDecimal bySeqNo;

	@Column(name = "revSeqNo")
	@JsonProperty("revSeqNo")
	@Getter
	@Setter
	public BigDecimal revSeqNo;

	@Column(name = "attachmentId")
	@JsonProperty("attachmentId")
	@Getter
	@Setter
	public String attachmentId;

	@Column(name = "availableFromDate")
	@Getter
	@Setter
	public Date availableFromDate_temp;

	@Transient
	@JsonProperty("availableFromDate")
	@Getter
	public BigDecimal availableFromDate;

	public void setAvailableFromDate(BigDecimal availableFromDate) {
		if(availableFromDate != null) {
			this.availableFromDate_temp = Utils.convertTimeFromEpoch(availableFromDate);
			this.availableFromDate = availableFromDate;
		}
	}

	@Column(name = "availableToDate")
	@Getter
	@Setter
	public Date availableToDate_temp;

	@Transient
	@JsonProperty("availableToDate")
	@Getter
	public BigDecimal availableToDate;

	public void setAvailableToDate(BigDecimal availableToDate) {
		if(availableToDate != null) {
			this.availableToDate_temp = Utils.convertTimeFromEpoch(availableToDate);
			this.availableToDate = availableToDate;
		}
	}

//	@Column(name = "clientAccessKey")
//	@JsonProperty("clientAccessKey")
//	@Getter
//	@Setter
//	public String clientAccessKey;

	@Column(name = "contentFileName")
	@JsonProperty("contentFileName")
	@Getter
	@Setter
	public String contentFileName;

	@Column(name = "createdBy")
	@JsonProperty("createdBy")
	@Getter
	@Setter
	public String createdBy;

	@Column(name = "createdDate")
	@Getter
	@Setter
	public Date createdDate_temp;

	@Transient
	@JsonProperty("createdDate")
	@Getter
	public BigDecimal createdDate;

	public void setCreatedDate(BigDecimal createdDate) {
		if(createdDate != null) {
			this.createdDate_temp = Utils.convertTimeFromEpoch(createdDate);
			this.createdDate = createdDate;
		}
}

	@Column(name = "description")
	@JsonProperty("description")
	@Getter
	@Setter
	public String description;

	@Column(name = "fixTemplate")
	@JsonProperty("fixedTemplate")
	@Getter
	@Setter
	public String fixTemplate;

	@Column(name = "footerFileName")
	@JsonProperty("footerFileName")
	@Getter
	@Setter
	public String footerFileName;

	@Column(name = "headerFileName")
	@JsonProperty("headerFileName")
	@Getter
	@Setter
	public String headerFileName;

	@Column(name = "idCounter")
	@JsonProperty("idCounter")
	@Getter
	@Setter
	public BigDecimal idCounter;

	@Column(name = "idPrefix")
	@JsonProperty("idPrefix")
	@Getter
	@Setter
	public String idPrefix;

	@Column(name = "includeSA")
	@JsonProperty("includeSA")
	@Getter
	@Setter
	public String includeSA;

	@Column(name = "isMultiOption")
	@JsonProperty("isMultiOption")
	@Getter
	@Setter
	public String isMultiOption;

	@Column(name = "isNew")
	@JsonProperty("isNew")
	@Getter
	@Setter
	public String isNew;

	@Column(name = "isRegister")
	@JsonProperty("isRegister")
	@Getter
	@Setter
	public String isRegister;

	@Column(name = "isRegisterLimit")
	@JsonProperty("isRegisterLimit")
	@Getter
	@Setter
	public String isRegisterLimit;

	@Column(name = "optionName")
	@JsonProperty("optionName")
	@Getter
	@Setter
	public String optionName;

	@Column(name = "optionNum")
	@JsonProperty("optionNum")
	@Getter
	@Setter
	public BigDecimal optionNum;

	@Column(name = "optionTotal1")
	@JsonProperty("optionTotal1")
	@Getter
	@Setter
	public BigDecimal optionTotal1;

	@Column(name = "optionTotal2")
	@JsonProperty("optionTotal2")
	@Getter
	@Setter
	public BigDecimal optionTotal2;

	@Column(name = "optionTotal3")
	@JsonProperty("optionTotal3")
	@Getter
	@Setter
	public BigDecimal optionTotal3;

	@Column(name = "optionTotal4")
	@JsonProperty("optionTotal4")
	@Getter
	@Setter
	public BigDecimal optionTotal4;

	@Column(name = "optionTotal5")
	@JsonProperty("optionTotal5")
	@Getter
	@Setter
	public BigDecimal optionTotal5;

	@Column(name = "receiverFileName")
	@JsonProperty("receiverFileName")
	@Getter
	@Setter
	public String receiverFileName;

	@Column(name = "registerExpireDate")
	@Getter
	@Setter
	public Date registerExpireDate_temp;

	@Transient
	@JsonProperty("registerExpireDate")
	@Getter
	public BigDecimal registerExpireDate;

	public void setRegisterExpireDate(BigDecimal registerExpireDate) {
		if(registerExpireDate != null) {
			this.registerExpireDate_temp = Utils.convertTimeFromEpoch(registerExpireDate);
			this.registerExpireDate = registerExpireDate;
		}
	}

	@Column(name = "registerLimitNum")
	@JsonProperty("registerLimitNum")
	@Getter
	@Setter
	public BigDecimal registerLimitNum;

	@Column(name = "scheduleSendDate")
	@Getter
	@Setter
	public Date scheduleSendDate_temp;

	@Transient
	@JsonProperty("scheduleSendDate")
	@Getter
	public BigDecimal scheduleSendDate;

	public void setScheduleSendDate(BigDecimal scheduleSendDate) {
		if(scheduleSendDate != null) {
			this.scheduleSendDate_temp = Utils.convertTimeFromEpoch(scheduleSendDate);
			this.scheduleSendDate = scheduleSendDate;
		}
}

	@Column(name = "sendAll")
	@JsonProperty("sendAll")
	@Getter
	@Setter
	public String sendAll;

	@Column(name = "status")
	@JsonProperty("status")
	@Getter
	@Setter
	public String status;

	@Transient
	@JsonProperty("sync")
	@Getter
	public Sync sync;

	public void setSync(Sync sy) throws Exception {
		if(sy != null) {
			this.sync = sy;
			this.sync_channel = sync.getChannel();
			this.sync_accessChannel = sync.getAccessChannel();
			this.sync_accessUser = sync.getAccessUser();
			this.sync_requireAdmin = sync.getRequireAdmin();
			this.sync_requireUser = sync.getRequireUser();
			this.sync_requireAccess = sync.getRequireAccess();
			this.sync_expiry = sync.getExpiry();
		}
	}

	@Column(name = "sync_channel")
	@Getter
	@Setter
	public String sync_channel;

	@Column(name = "sync_accessChannel")
	@Getter
	@Setter
	public String sync_accessChannel;

	@Column(name = "sync_accessUser")
	@Getter
	@Setter
	public String sync_accessUser;

	@Column(name = "sync_requireAdmin")
	@Getter
	@Setter
	public String sync_requireAdmin;

	@Column(name = "sync_requireUser")
	@Getter
	@Setter
	public String sync_requireUser;

	@Column(name = "sync_requireAccess")
	@Getter
	@Setter
	public String sync_requireAccess;

	@Column(name = "sync_expiry")
	@Getter
	@Setter
	public Date sync_expiry;

	@Column(name = "title")
	@JsonProperty("title")
	@Getter
	@Setter
	public String title;

	@Column(name = "totalLike")
	@JsonProperty("totalLike")
	@Getter
	@Setter
	public BigDecimal totalLike;

	@Column(name = "totalRegister")
	@JsonProperty("totalRegister")
	@Getter
	@Setter
	public BigDecimal totalRegister;

	@Column(name = "type")
	@JsonProperty("type")
	@Getter
	@Setter
	public String type;

	@Column(name = "typekey")
	@JsonProperty("typekey")
	@Getter
	@Setter
	public String typekey;

	@Column(name = "updateBy")
	@JsonProperty("updatedBy")
	@Getter
	@Setter
	public String updateBy;

	@Column(name = "updateDate")
	@Getter
	@Setter
	public Date updateDate_temp;

	@Transient
	@JsonProperty("updatedDate")
	@Getter
	public BigDecimal updateDate;

	public void setUpdateDate(BigDecimal updateDate) {
		if(updateDate != null) {
			this.updateDate_temp = Utils.convertTimeFromEpoch(updateDate);
			this.updateDate = updateDate;
		}
	}

//	@Column(name = "header")
//	@JsonProperty("header")
//	@Getter
//	@Setter
//	public String header;
//
//	@Column(name = "footer")
//	@JsonProperty("footer")
//	@Getter
//	@Setter
//	public String footer;
//
//	@Column(name = "body")
//	@JsonProperty("body")
//	@Getter
//	@Setter
//	public String body;

	public void save(Session session, Payload payload){
		Transaction transaction = session.beginTransaction();
		if(payload.event.trim().toLowerCase().equals("mutation")) {
			session.merge(this);
		}
		else{
			if(payload.event.trim().toLowerCase().equals("deletion") ||
					payload.event.trim().toLowerCase().equals("expiration")){
				session.delete(session.merge(this));
			}
		}
		transaction.commit();
	}
}