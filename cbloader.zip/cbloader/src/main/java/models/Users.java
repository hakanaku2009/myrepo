package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import models.common.Payload;
import utils.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "Users")
public class Users implements Serializable{
	public Users(){}

	@Id
	@Column(name = "key")
	@JsonProperty("key")
	@Getter
	@Setter
	public String key;

	@Column(name = "cas")
	@JsonProperty("cas")
	@Getter
	@Setter
	public String cas;

	@Column(name = "bySeqNo")
	@JsonProperty("bySeqNo")
	@Getter
	@Setter
	public BigDecimal bySeqNo;

	@Column(name = "revSeqNo")
	@JsonProperty("revSeqNo")
	@Getter
	@Setter
	public BigDecimal revSeqNo;

	@Column(name = "email")
	@JsonProperty("email")
	@Getter
	@Setter
	public String email;

	@Column(name = "fullName")
	@JsonProperty("fullName")
	@Getter
	@Setter
	public String fullName;

	@Column(name = "id")
	@JsonProperty("id")
	@Getter
	@Setter
	public String id;

	@Column(name = "idCounter")
	@JsonProperty("idCounter")
	@Getter
	@Setter
	public BigDecimal idCounter;

	@Column(name = "idPrefix")
	@JsonProperty("idPrefix")
	@Getter
	@Setter
	public String idPrefix;

	@Column(name = "lastLoginDate")
	@Getter
	@Setter
	public Date lastLoginDate_temp;

	@Transient
	@JsonProperty("lastLoginDate")
	@Getter
	public BigDecimal lastLoginDate;

	public void setLastLoginDate(BigDecimal loginDate){
		if(loginDate != null) {
			lastLoginDate_temp = Utils.convertTimeFromEpoch(loginDate);
			this.lastLoginDate = loginDate;
		}
	}

	@Column(name = "role")
	@JsonProperty("role")
	@Getter
	@Setter
	public String role;

	@Transient
	@JsonProperty("roles")
	@Getter
	@Setter
	public List<String> roles;

	@Column(name = "roles")
	@Getter
	public String roles_temp;

	public void setRoles(List<String> list){
		this.roles = list;
		roles_temp = "";
		for(int i = 0; i < roles.size(); i++){
			if(i == 0){
				roles_temp += roles.get(i);
			}
			else{
				roles_temp += ", " + roles.get(i);
			}
		}
	}

	@Transient
	@JsonProperty("sync")
	@Getter
	public Sync sync;

	public void setSync(Sync sy) throws Exception {
		if(sy != null) {
			this.sync = sy;
			this.sync_channel = sync.getChannel();
			this.sync_accessChannel = sync.getAccessChannel();
			this.sync_accessUser = sync.getAccessUser();
			this.sync_requireAdmin = sync.getRequireAdmin();
			this.sync_requireUser = sync.getRequireUser();
			this.sync_requireAccess = sync.getRequireAccess();
			this.sync_expiry = sync.getExpiry();
		}
	}

	@Column(name = "sync_channel")
	@Getter
	@Setter
	public String sync_channel;

	@Column(name = "sync_accessChannel")
	@Getter
	@Setter
	public String sync_accessChannel;

	@Column(name = "sync_accessUser")
	@Getter
	@Setter
	public String sync_accessUser;

	@Column(name = "sync_requireAdmin")
	@Getter
	@Setter
	public String sync_requireAdmin;

	@Column(name = "sync_requireUser")
	@Getter
	@Setter
	public String sync_requireUser;

	@Column(name = "sync_requireAccess")
	@Getter
	@Setter
	public String sync_requireAccess;

	@Column(name = "sync_expiry")
	@Getter
	@Setter
	public Date sync_expiry;

	@Column(name = "typekey")
	@JsonProperty("typekey")
	@Getter
	@Setter
	public String typekey;

	@Column(name = "username")
	@JsonProperty("username")
	@Getter
	@Setter
	public String username;

	public void save(Session session, Payload payload){
		Transaction transaction = session.beginTransaction();
		if(payload.event.trim().toLowerCase().equals("mutation")) {
			session.merge(this);
		}
		else{
			if(payload.event.trim().toLowerCase().equals("deletion") ||
					payload.event.trim().toLowerCase().equals("expiration")){
				session.delete(session.merge(this));
			}
		}
		transaction.commit();
	}
}