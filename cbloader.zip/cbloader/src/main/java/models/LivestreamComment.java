package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import models.common.Payload;
import utils.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "LivestreamComment")
public class LivestreamComment implements Serializable{
	public LivestreamComment(){}

	@Id
	@Column(name = "key")
	@JsonProperty("key")
	@Getter
	@Setter
	public String key;

	@Column(name = "cas")
	@JsonProperty("cas")
	@Getter
	@Setter
	public String cas;

	@Column(name = "bySeqNo")
	@JsonProperty("bySeqNo")
	@Getter
	@Setter
	public BigDecimal bySeqNo;

	@Column(name = "revSeqNo")
	@JsonProperty("revSeqNo")
	@Getter
	@Setter
	public BigDecimal revSeqNo;

	@Column(name = "agentCode")
	@JsonProperty("agentCode")
	@Getter
	@Setter
	public String agentCode;

	@Column(name = "agentName")
	@JsonProperty("agentName")
	@Getter
	@Setter
	public String agentName;

	@Column(name = "content")
	@JsonProperty("content")
	@Getter
	@Setter
	public String content;

	@Column(name = "createdAt")
	@Getter
	@Setter
	public Date createdAt_temp;

	@Transient
	@JsonProperty("createdAt")
	@Getter
	public String createdAt;

	public void setCreatedAt(String createdAt) throws Exception{
		if(createdAt != null && !createdAt.trim().equals("")) {
			this.createdAt_temp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX").parse(createdAt);
			this.createdAt = createdAt;
		}
}

	@Column(name = "livestreamId")
	@JsonProperty("livestreamId")
	@Getter
	@Setter
	public String livestreamId;

	@Column(name = "status")
	@JsonProperty("status")
	@Getter
	@Setter
	public String status;

	@Transient
	@JsonProperty("sync")
	@Getter
	public Sync sync;

	public void setSync(Sync sy) throws Exception {
		if(sy != null) {
			this.sync = sy;
			this.sync_channel = sync.getChannel();
			this.sync_accessChannel = sync.getAccessChannel();
			this.sync_accessUser = sync.getAccessUser();
			this.sync_requireAdmin = sync.getRequireAdmin();
			this.sync_requireUser = sync.getRequireUser();
			this.sync_requireAccess = sync.getRequireAccess();
			this.sync_expiry = sync.getExpiry();
		}
	}

	@Column(name = "sync_channel")
	@Getter
	@Setter
	public String sync_channel;

	@Column(name = "sync_accessChannel")
	@Getter
	@Setter
	public String sync_accessChannel;

	@Column(name = "sync_accessUser")
	@Getter
	@Setter
	public String sync_accessUser;

	@Column(name = "sync_requireAdmin")
	@Getter
	@Setter
	public String sync_requireAdmin;

	@Column(name = "sync_requireUser")
	@Getter
	@Setter
	public String sync_requireUser;

	@Column(name = "sync_requireAccess")
	@Getter
	@Setter
	public String sync_requireAccess;

	@Column(name = "sync_expiry")
	@Getter
	@Setter
	public Date sync_expiry;

	@Column(name = "typekey")
	@JsonProperty("typekey")
	@Getter
	@Setter
	public String typekey;

	public void save(Session session, Payload payload){
		Transaction transaction = session.beginTransaction();
		if(payload.event.trim().toLowerCase().equals("mutation")) {
			session.merge(this);
		}
		else{
			if(payload.event.trim().toLowerCase().equals("deletion") ||
					payload.event.trim().toLowerCase().equals("expiration")){
				session.delete(session.merge(this));
			}
		}
		transaction.commit();
	}
}