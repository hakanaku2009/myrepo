package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import models.common.Payload;
import utils.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "RegisterAgent")
public class RegisterAgent implements Serializable{
	public RegisterAgent(){}

	@Id
	@Column(name = "key")
	@JsonProperty("key")
	@Getter
	@Setter
	public String key;

	@Column(name = "cas")
	@JsonProperty("cas")
	@Getter
	@Setter
	public String cas;

	@Column(name = "bySeqNo")
	@JsonProperty("bySeqNo")
	@Getter
	@Setter
	public BigDecimal bySeqNo;

	@Column(name = "revSeqNo")
	@JsonProperty("revSeqNo")
	@Getter
	@Setter
	public BigDecimal revSeqNo;

	@Column(name = "agentCode")
	@JsonProperty("agentCode")
	@Getter
	@Setter
	public String agentCode;

	@Column(name = "callDate")
	@Getter
	@Setter
	public Date callDate_temp;

	@Transient
	@JsonProperty("callDate")
	@Getter
	public BigDecimal callDate;

	public void setCallDate(BigDecimal callDate) {
		if(callDate != null) {
			this.callDate_temp = Utils.convertTimeFromEpoch(callDate);
			this.callDate = callDate;
		}
	}

	@Column(name = "callStatus")
	@JsonProperty("callStatus")
	@Getter
	@Setter
	public String callStatus;

//	@Column(name = "clientAccessKey")
//	@JsonProperty("clientAccessKey")
//	@Getter
//	@Setter
//	public String clientAccessKey;

	@Column(name = "earnPoint")
	@JsonProperty("earnPoint")
	@Getter
	@Setter
	public String earnPoint;

	@Column(name = "fullName")
	@JsonProperty("fullName")
	@Getter
	@Setter
	public String fullName;

	@Column(name = "idCounter")
	@JsonProperty("idCounter")
	@Getter
	@Setter
	public String idCounter;

	@Column(name = "idPrefix")
	@JsonProperty("idPrefix")
	@Getter
	@Setter
	public String idPrefix;

	@Column(name = "leaderCode")
	@JsonProperty("leaderCode")
	@Getter
	@Setter
	public String leaderCode;

	@Column(name = "phone")
	@JsonProperty("phone")
	@Getter
	@Setter
	public String phone;

	@Column(name = "referralCode")
	@JsonProperty("referralCode")
	@Getter
	@Setter
	public String referralCode;

	@Column(name = "registerDate")
	@Getter
	@Setter
	public Date registerDate_temp;

	@Transient
	@JsonProperty("registerDate")
	@Getter
	public BigDecimal registerDate;

	public void setRegisterDate(BigDecimal registerDate) {
		if(registerDate != null) {
			this.registerDate_temp = Utils.convertTimeFromEpoch(registerDate);
			this.registerDate = registerDate;
		}
}

	@Column(name = "subType")
	@JsonProperty("subType")
	@Getter
	@Setter
	public String subType;

	@Column(name = "type")
	@JsonProperty("type")
	@Getter
	@Setter
	public String type;

	@Column(name = "typekey")
	@JsonProperty("typekey")
	@Getter
	@Setter
	public String typekey;

	@Column(name = "leaderName")
	@JsonProperty("leaderName")
	@Getter
	@Setter
	public String leaderName;

	@Column(name = "numberOfRemind")
	@JsonProperty("numberOfRemind")
	@Getter
	@Setter
	public BigDecimal numberOfRemind;

	public void save(Session session, Payload payload){
		Transaction transaction = session.beginTransaction();
		if(payload.event.trim().toLowerCase().equals("mutation")) {
			session.merge(this);
		}
		else{
			if(payload.event.trim().toLowerCase().equals("deletion") ||
					payload.event.trim().toLowerCase().equals("expiration")){
				session.delete(session.merge(this));
			}
		}
		transaction.commit();
	}
}