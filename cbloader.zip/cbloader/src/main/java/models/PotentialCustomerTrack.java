package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import models.common.Payload;
import utils.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "PotentialCustomerTrack")
public class PotentialCustomerTrack implements Serializable{
	public PotentialCustomerTrack(){}

	@Id
	@Column(name = "key")
	@JsonProperty("key")
	@Getter
	@Setter
	public String key;

	@Column(name = "cas")
	@JsonProperty("cas")
	@Getter
	@Setter
	public String cas;

	@Column(name = "bySeqNo")
	@JsonProperty("bySeqNo")
	@Getter
	@Setter
	public BigDecimal bySeqNo;

	@Column(name = "revSeqNo")
	@JsonProperty("revSeqNo")
	@Getter
	@Setter
	public BigDecimal revSeqNo;

	@Column(name = "candidateID")
	@JsonProperty("candidateID")
	@Getter
	@Setter
	public String candidateID;

	@Column(name = "count")
	@JsonProperty("count")
	@Getter
	@Setter
	public BigDecimal count;

	@Column(name = "key_track")
	@JsonProperty("key_track")
	@Getter
	@Setter
	public String key_track;

	@Column(name = "createdAt")
	@Getter
	@Setter
	public Date createdAt_temp;

	@Transient
	@JsonProperty("createdAt")
	@Getter
	public String createdAt;

	public void setCreatedAt(String ca) throws Exception{
		if(ca != null && !ca.trim().equals("")) {
			this.createdAt_temp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX").parse(ca);
			this.createdAt = ca;
		}
	}

	@Column(name = "isSendedNoti")
	@JsonProperty("isSendedNoti")
	@Getter
	@Setter
	public String isSendedNoti;

	@Column(name = "name")
	@JsonProperty("name")
	@Getter
	@Setter
	public String name;

	@Column(name = "typekey")
	@JsonProperty("typekey")
	@Getter
	@Setter
	public String typekey;

	public void save(Session session, Payload payload){
		Transaction transaction = session.beginTransaction();
		if(payload.event.trim().toLowerCase().equals("mutation")) {
			session.merge(this);
		}
		else{
			if(payload.event.trim().toLowerCase().equals("deletion") ||
					payload.event.trim().toLowerCase().equals("expiration")){
				session.delete(session.merge(this));
			}
		}
		transaction.commit();
	}
}