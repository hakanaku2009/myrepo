package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import models.common.Payload;
import utils.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "ActionTracking")
public class ActionTracking implements Serializable{
	public ActionTracking(){}

	@Id
	@Column(name = "key")
	@JsonProperty("key")
	@Getter
	@Setter
	public String key;

	@Column(name = "cas")
	@JsonProperty("cas")
	@Getter
	@Setter
	public String cas;

	@Column(name = "bySeqNo")
	@JsonProperty("bySeqNo")
	@Getter
	@Setter
	public BigDecimal bySeqNo;

	@Column(name = "revSeqNo")
	@JsonProperty("revSeqNo")
	@Getter
	@Setter
	public BigDecimal revSeqNo;

	@Column(name = "actionName")
	@JsonProperty("actionName")
	@Getter
	@Setter
	public String actionName;

	@Column(name = "agentCode")
	@JsonProperty("agentCode")
	@Getter
	@Setter
	public String agentCode;

	@Column(name = "agentName")
	@JsonProperty("agentName")
	@Getter
	@Setter
	public String agentName;

//	@Column(name = "body")
//	@JsonProperty("body")
//	@Getter
//	@Setter
//	public String body;

	@Column(name = "branchCode")
	@JsonProperty("branchCode")
	@Getter
	@Setter
	public String branchCode;

//	@Column(name = "clientAccessKey")
//	@JsonProperty("clientAccessKey")
//	@Getter
//	@Setter
//	public String clientAccessKey;

	@Column(name = "createAt")
	@JsonProperty("createAt")
	@Getter
	@Setter
	public String createAt;

	@Column(name = "createdDate")
	@Getter
	@Setter
	public Date createdDate_temp;

	@Transient
	@JsonProperty("createdDate")
	@Getter
	public BigDecimal createdDate;

	public void setCreatedDate(BigDecimal createdDate) {
		if(createdDate != null) {
			this.createdDate_temp = Utils.convertTimeFromEpoch(createdDate);
			this.createdDate = createdDate;
		}
}

	@Column(name = "officeCode")
	@JsonProperty("officeCode")
	@Getter
	@Setter
	public String officeCode;

	@Column(name = "position")
	@JsonProperty("position")
	@Getter
	@Setter
	public String position;

	@Column(name = "subType")
	@JsonProperty("subType")
	@Getter
	@Setter
	public String subType;

	@Column(name = "typekey")
	@JsonProperty("typekey")
	@Getter
	@Setter
	public String typekey;

	@Column(name = "unitCode")
	@JsonProperty("unitCode")
	@Getter
	@Setter
	public String unitCode;

	@Column(name = "welcomePopupId")
	@JsonProperty("welcomePopupId")
	@Getter
	@Setter
	public String welcomePopupId;

	public void save(Session session, Payload payload){
		Transaction transaction = session.beginTransaction();
		if(payload.event.trim().toLowerCase().equals("mutation")) {
			session.merge(this);
		}
		else{
			if(payload.event.trim().toLowerCase().equals("deletion") ||
			payload.event.trim().toLowerCase().equals("expiration")){
				session.delete(session.merge(this));
			}
		}
		transaction.commit();
	}
}