package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import models.common.Payload;
import utils.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "OTPRecord")
public class OTPRecord implements Serializable{
	public OTPRecord(){}

	@Id
	@Column(name = "key")
	@Getter
	@Setter
	public String key;

	@Column(name = "cas")
	@JsonProperty("cas")
	@Getter
	@Setter
	public String cas;

	@Column(name = "bySeqNo")
	@JsonProperty("bySeqNo")
	@Getter
	@Setter
	public BigDecimal bySeqNo;

	@Column(name = "revSeqNo")
	@JsonProperty("revSeqNo")
	@Getter
	@Setter
	public BigDecimal revSeqNo;

	@Column(name = "code")
	@JsonProperty("code")
	@Getter
	@Setter
	public String code;

	@Column(name = "isUsed")
	@JsonProperty("isUsed")
	@Getter
	@Setter
	public String isUsed;

//	@Column(name = "key_otp")
//	@JsonProperty("key")
//	@Getter
//	@Setter
//	public String key_otp;

	@Transient
	@JsonProperty("method")
	@Getter
	public OTPMethod method;

	public void setMethod(OTPMethod meth){
		if(meth != null) {
			this.method = meth;
			this.method_tag = method.tag;
			this.method_value = method.value;
		}
	}

	@Column(name = "method_tag")
	@Getter
	@Setter
	public String method_tag;

	@Column(name = "method_value")
	@Getter
	@Setter
	public String method_value;

	@Column(name = "name")
	@JsonProperty("name")
	@Getter
	@Setter
	public String name;

	@Column(name = "sendAt")
	@Getter
	@Setter
	public Date sendAt_temp;

	@Transient
	@JsonProperty("sentAt")
	@Getter
	public String sendAt;

	public void setSendAt(String sendAt) throws Exception{
		if(sendAt != null && !sendAt.trim().equals("")) {
			this.sendAt_temp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX").parse(sendAt);
			this.sendAt = sendAt;
		}
	}

	@Column(name = "typekey")
	@JsonProperty("typekey")
	@Getter
	@Setter
	public String typekey;

	public void save(Session session, Payload payload){
		Transaction transaction = session.beginTransaction();
		if(payload.event.trim().toLowerCase().equals("mutation")) {
			session.merge(this);
		}
		else{
			if(payload.event.trim().toLowerCase().equals("deletion") ||
					payload.event.trim().toLowerCase().equals("expiration")){
				session.delete(session.merge(this));
			}
		}
		transaction.commit();
	}
}