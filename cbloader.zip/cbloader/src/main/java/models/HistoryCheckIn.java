package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import models.common.Payload;
import utils.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "HistoryCheckIn")
public class HistoryCheckIn implements Serializable{
	public HistoryCheckIn(){}

	@Id
	@Column(name = "key")
	@JsonProperty("key")
	@Getter
	@Setter
	public String key;

	@Column(name = "cas")
	@JsonProperty("cas")
	@Getter
	@Setter
	public String cas;

	@Column(name = "bySeqNo")
	@JsonProperty("bySeqNo")
	@Getter
	@Setter
	public BigDecimal bySeqNo;

	@Column(name = "revSeqNo")
	@JsonProperty("revSeqNo")
	@Getter
	@Setter
	public BigDecimal revSeqNo;

	@Column(name = "QRCode")
	@JsonProperty("QRCode")
	@Getter
	@Setter
	public String QRCode;

	@Column(name = "agentCode")
	@JsonProperty("agentCode")
	@Getter
	@Setter
	public String agentCode;

	@Column(name = "agentDomainAccount")
	@JsonProperty("agentDomainAccount")
	@Getter
	@Setter
	public String agentDomainAccount;

	@Column(name = "agentDomainName")
	@JsonProperty("agentDomainName")
	@Getter
	@Setter
	public String agentDomainName;

	@Column(name = "agentName")
	@JsonProperty("agentName")
	@Getter
	@Setter
	public String agentName;

	@Column(name = "checkInDate")
	@Getter
	@Setter
	public Date checkInDate_temp;

	@Transient
	@JsonProperty("checkInDate")
	@Getter
	public BigDecimal checkInDate;

	public void setCheckInDate(BigDecimal checkInDate) {
		if(checkInDate != null) {
			this.checkInDate_temp = Utils.convertTimeFromEpoch(checkInDate);
			this.checkInDate = checkInDate;
		}
}

//	@Column(name = "clientAccessKey")
//	@JsonProperty("clientAccessKey")
//	@Getter
//	@Setter
//	public String clientAccessKey;

	@Column(name = "contentId")
	@JsonProperty("contentId")
	@Getter
	@Setter
	public String contentId;

	@Column(name = "idCounter")
	@JsonProperty("idCounter")
	@Getter
	@Setter
	public BigDecimal idCounter;

	@Column(name = "idPrefix")
	@JsonProperty("idPrefix")
	@Getter
	@Setter
	public String idPrefix;

	@Column(name = "latitude")
	@JsonProperty("latitude")
	@Getter
	@Setter
	public BigDecimal latitude;

	@Column(name = "longitude")
	@JsonProperty("longitude")
	@Getter
	@Setter
	public BigDecimal longitude;

	@Column(name = "rateDate")
	@Getter
	@Setter
	public Date rateDate_temp;

	@Transient
	@JsonProperty("rateDate")
	@Getter
	public BigDecimal rateDate;

	public void setRateDate(BigDecimal rateDate) {
		if(rateDate != null) {
			this.rateDate_temp = Utils.convertTimeFromEpoch(rateDate);
			this.rateDate = rateDate;
		}
}

	@Column(name = "rating")
	@JsonProperty("rating")
	@Getter
	@Setter
	public BigDecimal rating;

	@Column(name = "typekey")
	@JsonProperty("typekey")
	@Getter
	@Setter
	public String typekey;

	@Column(name = "unitCode")
	@JsonProperty("unitCode")
	@Getter
	@Setter
	public String unitCode;

	public void save(Session session, Payload payload){
		Transaction transaction = session.beginTransaction();
		if(payload.event.trim().toLowerCase().equals("mutation")) {
			session.merge(this);
		}
		else{
			if(payload.event.trim().toLowerCase().equals("deletion") ||
					payload.event.trim().toLowerCase().equals("expiration")){
				session.delete(session.merge(this));
			}
		}
		transaction.commit();
	}
}