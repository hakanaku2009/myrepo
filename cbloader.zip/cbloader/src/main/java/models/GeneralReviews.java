package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GeneralReviews implements Serializable{
    @JsonProperty("appearanceOrHealth")
    public String appearanceOrHealth;

    @JsonProperty("attitude")
    public String attitude;

    @JsonProperty("commitment")
    public String commitment;

    @JsonProperty("communicationSkill")
    public String communicationSkill;

    @JsonProperty("socialRelationship")
    public String socialRelationship;

    @JsonProperty("technicalAbility")
    public String technicalAbility;
}
