package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserGroupFilter implements Serializable{

    @JsonProperty("fileId")
    public String fileId;

    @JsonProperty("includeSA")
    public String includeSA;

    @JsonProperty("tag")
    public String tag;
}
