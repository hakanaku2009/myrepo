package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import models.common.Payload;
import utils.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "ActiveSa")
public class ActiveSa implements Serializable{
	public ActiveSa(){}

	@Id
	@Column(name = "key")
	@JsonProperty("key")
	@Getter
	@Setter
	public String key;

	@Column(name = "cas")
	@JsonProperty("cas")
	@Getter
	@Setter
	public String cas;

	@Column(name = "bySeqNo")
	@JsonProperty("bySeqNo")
	@Getter
	@Setter
	public BigDecimal bySeqNo;

	@Column(name = "revSeqNo")
	@JsonProperty("revSeqNo")
	@Getter
	@Setter
	public BigDecimal revSeqNo;

	@Column(name = "actionName")
	@JsonProperty("actionName")
	@Getter
	@Setter
	public String actionName;

	@Column(name = "agentCode")
	@JsonProperty("agentCode")
	@Getter
	@Setter
	public String agentCode;

	@Column(name = "agentName")
	@JsonProperty("agentName")
	@Getter
	@Setter
	public String agentName;

	@Column(name = "callBy")
	@JsonProperty("callBy")
	@Getter
	@Setter
	public String callBy;

	@Column(name = "callDate")
	@Getter
	@Setter
	public Date callDate_temp;

	@Transient
	@JsonProperty("callDate")
	@Getter
	public BigDecimal callDate;

	public void setCallDate(BigDecimal callDate) {
		if(callDate != null) {
			this.callDate_temp = Utils.convertTimeFromEpoch(callDate);
			this.callDate = callDate;
		}
}

	@Column(name = "createdDate")
	@Getter
	@Setter
	public Date createdDate_temp;

	@Transient
	@JsonProperty("createdDate")
	@Getter
	public BigDecimal createdDate;

	public void setCreatedDate(BigDecimal createdDate) {
		if(createdDate != null) {
			this.createdDate_temp = Utils.convertTimeFromEpoch(createdDate);
			this.createdDate = createdDate;
		}
	}

	@Column(name = "idCounter")
	@JsonProperty("idCounter")
	@Getter
	@Setter
	public BigDecimal idCounter;

	@Column(name = "idPrefix")
	@JsonProperty("idPrefix")
	@Getter
	@Setter
	public String idPrefix;

	@Column(name = "joinAt")
	@Getter
	@Setter
	public Date joinAt_temp;

	@Transient
	@JsonProperty("joinAt")
	@Getter
	public String joinAt;

	public void setJoinAt(String joinAt) throws Exception{
		if(joinAt != null && !joinAt.trim().equals("")) {
			this.joinAt_temp = new SimpleDateFormat("dd/MM/yyyy").parse(joinAt);
			this.joinAt = joinAt;
		}
	}

	@Column(name = "officeCode")
	@JsonProperty("officeCode")
	@Getter
	@Setter
	public String officeCode;

	@Column(name = "phone")
	@JsonProperty("phone")
	@Getter
	@Setter
	public String phone;

	@Column(name = "position")
	@JsonProperty("position")
	@Getter
	@Setter
	public String position;

	@Column(name = "shareBy")
	@JsonProperty("shareBy")
	@Getter
	@Setter
	public String shareBy;

	@Column(name = "system")
	@JsonProperty("system")
	@Getter
	@Setter
	public String system;

	@Column(name = "type")
	@JsonProperty("type")
	@Getter
	@Setter
	public String type;

	@Column(name = "typekey")
	@JsonProperty("typekey")
	@Getter
	@Setter
	public String typekey;

	@Column(name = "unitCode")
	@JsonProperty("unitCode")
	@Getter
	@Setter
	public String unitCode;

	public void save(Session session, Payload payload){
		Transaction transaction = session.beginTransaction();
		if(payload.event.trim().toLowerCase().equals("mutation")) {
			session.merge(this);
		}
		else{
			if(payload.event.trim().toLowerCase().equals("deletion") ||
					payload.event.trim().toLowerCase().equals("expiration")){
				session.delete(session.merge(this));
			}
		}
		transaction.commit();
	}
}