package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import models.common.Payload;
import utils.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "MessageDetail")
public class MessageDetail implements Serializable{
	public MessageDetail(){}

	@Id
	@Column(name = "key")
	@JsonProperty("key")
	@Getter
	@Setter
	public String key;

	@Column(name = "cas")
	@JsonProperty("cas")
	@Getter
	@Setter
	public String cas;

	@Column(name = "bySeqNo")
	@JsonProperty("bySeqNo")
	@Getter
	@Setter
	public BigDecimal bySeqNo;

	@Column(name = "revSeqNo")
	@JsonProperty("revSeqNo")
	@Getter
	@Setter
	public BigDecimal revSeqNo;

	@Column(name = "agentCode")
	@JsonProperty("agentCode")
	@Getter
	@Setter
	public String agentCode;

	@Column(name = "attachmentId")
	@JsonProperty("attachmentId")
	@Getter
	@Setter
	public String attachmentId;

	@Column(name = "branchCode")
	@JsonProperty("branchCode")
	@Getter
	@Setter
	public String branchCode;

//	@Column(name = "clientAccessKey")
//	@JsonProperty("clientAccessKey")
//	@Getter
//	@Setter
//	public String clientAccessKey;

//	@Column(name = "content")
//	@JsonProperty("content")
//	@Getter
//	@Setter
//	public String content;

	@Column(name = "colA")
	@JsonProperty("colA")
	@Getter
	@Setter
	public String colA;

	@Column(name = "colB")
	@JsonProperty("colB")
	@Getter
	@Setter
	public String colB;

	@Column(name = "colC")
	@JsonProperty("colC")
	@Getter
	@Setter
	public String colC;

	@Column(name = "colD")
	@JsonProperty("colD")
	@Getter
	@Setter
	public String colD;

	@Column(name = "colE")
	@JsonProperty("colE")
	@Getter
	@Setter
	public String colE;

	@Column(name = "colF")
	@JsonProperty("colF")
	@Getter
	@Setter
	public String colF;

	@Column(name = "colG")
	@JsonProperty("colG")
	@Getter
	@Setter
	public String colG;

	@Column(name = "colH")
	@JsonProperty("colH")
	@Getter
	@Setter
	public String colH;

	@Column(name = "colI")
	@JsonProperty("colI")
	@Getter
	@Setter
	public String colI;

	@Column(name = "colJ")
	@JsonProperty("colJ")
	@Getter
	@Setter
	public String colJ;

	@Column(name = "createdDate")
	@Getter
	@Setter
	public Date createdDate_temp;

	@Transient
	@JsonProperty("createdDate")
	@Getter
	public BigDecimal createdDate;

	public void setCreatedDate(BigDecimal createdDate) {
		if(createdDate != null) {
			this.createdDate_temp = Utils.convertTimeFromEpoch(createdDate);
			this.createdDate = createdDate;
		}
}

	@Column(name = "description")
	@JsonProperty("description")
	@Getter
	@Setter
	public String description;

	@Column(name = "firstViewDate")
	@Getter
	@Setter
	public Date firstViewDate_temp;

	@Transient
	@JsonProperty("firstViewDate")
	@Getter
	public BigDecimal firstViewDate;

	public void setFirstViewDate(BigDecimal firstViewDate) {
		if(firstViewDate != null) {
			this.firstViewDate_temp = Utils.convertTimeFromEpoch(firstViewDate);
			this.firstViewDate = firstViewDate;
		}
}

	@Column(name = "idCounter")
	@JsonProperty("idCounter")
	@Getter
	@Setter
	public BigDecimal idCounter;

	@Column(name = "idPrefix")
	@JsonProperty("idPrefix")
	@Getter
	@Setter
	public String idPrefix;

	@Column(name = "isLike")
	@JsonProperty("isLike")
	@Getter
	@Setter
	public String isLike;

	@Column(name = "isReferral")
	@JsonProperty("isReferral")
	@Getter
	@Setter
	public String isReferral;

	@Column(name = "isSend")
	@JsonProperty("isSend")
	@Getter
	@Setter
	public String isSend;

	@Column(name = "lastViewDate")
	@Getter
	@Setter
	public Date lastViewDate_temp;

	@Transient
	@JsonProperty("lastViewDate")
	@Getter
	public BigDecimal lastViewDate;

	public void setLastViewDate(BigDecimal lastViewDate) {
		if(lastViewDate != null) {
			this.lastViewDate_temp = Utils.convertTimeFromEpoch(lastViewDate);
			this.lastViewDate = lastViewDate;
		}
}

	@Column(name = "messageId")
	@JsonProperty("messageId")
	@Getter
	@Setter
	public String messageId;

	@Column(name = "officeCode")
	@JsonProperty("officeCode")
	@Getter
	@Setter
	public String officeCode;

	@Column(name = "pushManual")
	@JsonProperty("pushManual")
	@Getter
	@Setter
	public String pushManual;

	@Column(name = "read")
	@JsonProperty("read")
	@Getter
	@Setter
	public String read;

	@Column(name = "register")
	@JsonProperty("register")
	@Getter
	@Setter
	public String register;

	@Column(name = "registerDate")
	@Getter
	@Setter
	public Date registerDate_temp;

	@Transient
	@JsonProperty("registerDate")
	@Getter
	public BigDecimal registerDate;

	public void setRegisterDate(BigDecimal registerDate) {
		if(registerDate != null) {
			this.registerDate_temp = Utils.convertTimeFromEpoch(registerDate);
			this.registerDate = registerDate;
		}
	}

	@Column(name = "sendDate")
	@Getter
	@Setter
	public Date sendDate_temp;

	@Transient
	@JsonProperty("sendDate")
	@Getter
	public BigDecimal sendDate;

	public void setSendDate(BigDecimal sendDate) {
		if(sendDate != null) {
			this.sendDate_temp = Utils.convertTimeFromEpoch(sendDate);
			this.sendDate = sendDate;
		}
	}

	@Column(name = "registerPosition")
	@JsonProperty("registerPosition")
	@Getter
	@Setter
	public String registerPosition;

	@Column(name = "registerPositionKey")
	@JsonProperty("registerPositionKey")
	@Getter
	@Setter
	public String registerPositionKey;

	@Column(name = "scheduleSendDate")
	@Getter
	@Setter
	public Date scheduleSendDate_temp;

	@Transient
	@JsonProperty("scheduleSendDate")
	@Getter
	public BigDecimal scheduleSendDate;

	public void setScheduleSendDate(BigDecimal scheduleSendDate) {
		if(scheduleSendDate != null) {
			this.scheduleSendDate_temp = Utils.convertTimeFromEpoch(scheduleSendDate);
			this.scheduleSendDate = scheduleSendDate;
		}
}

	@Column(name = "status")
	@JsonProperty("status")
	@Getter
	@Setter
	public String status;

	@Transient
	@JsonProperty("sync")
	@Getter
	public Sync sync;

	public void setSync(Sync sy) throws Exception {
		if(sy != null) {
			this.sync = sy;
			this.sync_channel = sync.getChannel();
			this.sync_accessChannel = sync.getAccessChannel();
			this.sync_accessUser = sync.getAccessUser();
			this.sync_requireAdmin = sync.getRequireAdmin();
			this.sync_requireUser = sync.getRequireUser();
			this.sync_requireAccess = sync.getRequireAccess();
			this.sync_expiry = sync.getExpiry();
		}
	}

	@Column(name = "sync_channel")
	@Getter
	@Setter
	public String sync_channel;

	@Column(name = "sync_accessChannel")
	@Getter
	@Setter
	public String sync_accessChannel;

	@Column(name = "sync_accessUser")
	@Getter
	@Setter
	public String sync_accessUser;

	@Column(name = "sync_requireAdmin")
	@Getter
	@Setter
	public String sync_requireAdmin;

	@Column(name = "sync_requireUser")
	@Getter
	@Setter
	public String sync_requireUser;

	@Column(name = "sync_requireAccess")
	@Getter
	@Setter
	public String sync_requireAccess;

	@Column(name = "sync_expiry")
	@Getter
	@Setter
	public Date sync_expiry;

	@Column(name = "title")
	@JsonProperty("title")
	@Getter
	@Setter
	public String title;

	@Column(name = "totalView")
	@JsonProperty("totalView")
	@Getter
	@Setter
	public BigDecimal totalView;

	@Column(name = "type")
	@JsonProperty("type")
	@Getter
	@Setter
	public String type;

	@Column(name = "typekey")
	@JsonProperty("typekey")
	@Getter
	@Setter
	public String typekey;

	@Column(name = "unitCode")
	@JsonProperty("unitCode")
	@Getter
	@Setter
	public String unitCode;

	@Column(name = "isRegisterSend")
	@JsonProperty("isRegisterSend")
	@Getter
	@Setter
	public String isRegisterSend;

	@Column(name = "registerSendDate")
	@Getter
	@Setter
	public Date registerSendDate_temp;

	@Transient
	@JsonProperty("registerSendDate")
	@Getter
	public BigDecimal registerSendDate;

	public void setRegisterSendDate(BigDecimal registerSendDate) {
		if(registerSendDate != null) {
			this.registerSendDate_temp = Utils.convertTimeFromEpoch(registerSendDate);
			this.registerSendDate = registerSendDate;
		}
	}

	public void save(Session session, Payload payload){
		Transaction transaction = session.beginTransaction();
		if(payload.event.trim().toLowerCase().equals("mutation")) {
			session.merge(this);
		}
		else{
			if(payload.event.trim().toLowerCase().equals("deletion") ||
					payload.event.trim().toLowerCase().equals("expiration")){
				session.delete(session.merge(this));
			}
		}
		transaction.commit();
	}
}