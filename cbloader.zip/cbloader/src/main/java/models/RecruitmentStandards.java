package models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RecruitmentStandards implements Serializable{

    @JsonProperty("isAge24To34")
    public String isAge24To34;

    @JsonProperty("isExperiencedWorking")
    public String isExperiencedWorking;

    @JsonProperty("isGraduatedHighSchool")
    public String isGraduatedHighSchool;

    @JsonProperty("isMarried")
    public String isMarried;

    @JsonProperty("isPotentialCustomerOver20")
    public String isPotentialCustomerOver20;
}
