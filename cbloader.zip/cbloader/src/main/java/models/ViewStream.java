package models;
import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ViewStream implements Serializable{

    @JsonProperty("count")
    public BigDecimal count;
    @JsonProperty("duration")
    public BigDecimal duration;
}
