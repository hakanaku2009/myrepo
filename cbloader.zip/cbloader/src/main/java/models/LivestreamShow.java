package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
public class LivestreamShow implements Serializable{

    @JsonProperty("liveDate")
    public String liveDate_temp;

    public void setLiveDate_temp(String liveDate_temp) throws Exception {
        if (liveDate_temp != null && !liveDate_temp.trim().equals("")) {
            this.liveDate_temp = liveDate_temp;
            this.liveDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX").parse(liveDate_temp);
        }
    }

    public Date liveDate;

    @JsonProperty("status")
    public String status;

    @JsonProperty("title")
    public String title;
}
