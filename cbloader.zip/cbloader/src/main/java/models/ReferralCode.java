package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import models.common.Payload;
import utils.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "ReferralCode")
public class ReferralCode implements Serializable{
	public ReferralCode(){}

	@Id
	@Column(name = "key")
	@JsonProperty("key")
	@Getter
	@Setter
	public String key;

	@Column(name = "cas")
	@JsonProperty("cas")
	@Getter
	@Setter
	public String cas;

	@Column(name = "bySeqNo")
	@JsonProperty("bySeqNo")
	@Getter
	@Setter
	public BigDecimal bySeqNo;

	@Column(name = "revSeqNo")
	@JsonProperty("revSeqNo")
	@Getter
	@Setter
	public BigDecimal revSeqNo;

	@Column(name = "agentCode")
	@JsonProperty("agentCode")
	@Getter
	@Setter
	public String agentCode;

	@Column(name = "agentName")
	@JsonProperty("agentName")
	@Getter
	@Setter
	public String agentName;

	@Column(name = "createdDate")
	@Getter
	@Setter
	public Date createdDate_temp;

	@Transient
	@JsonProperty("createdDate")
	@Getter
	public BigDecimal createdDate;

	public void setCreatedDate(BigDecimal createdDate) {
		if(createdDate != null) {
			this.createdDate_temp = Utils.convertTimeFromEpoch(createdDate);
			this.createdDate = createdDate;
		}
}

	@Column(name = "idCounter")
	@JsonProperty("idCounter")
	@Getter
	@Setter
	public String idCounter;

	@Column(name = "idPrefix")
	@JsonProperty("idPrefix")
	@Getter
	@Setter
	public String idPrefix;

	@Column(name = "leaderCode")
	@JsonProperty("leaderCode")
	@Getter
	@Setter
	public String leaderCode;

	@Column(name = "position")
	@JsonProperty("position")
	@Getter
	@Setter
	public String position;

	@Column(name = "referralCode")
	@JsonProperty("referralCode")
	@Getter
	@Setter
	public String referralCode;

	@Column(name = "referralCodeForCustomer")
	@JsonProperty("referralCodeForCustomer")
	@Getter
	@Setter
	public String referralCodeForCustomer;

	@Column(name = "typekey")
	@JsonProperty("typekey")
	@Getter
	@Setter
	public String typekey;

	public void save(Session session, Payload payload){
		Transaction transaction = session.beginTransaction();
		if(payload.event.trim().toLowerCase().equals("mutation")) {
			session.merge(this);
		}
		else{
			if(payload.event.trim().toLowerCase().equals("deletion") ||
					payload.event.trim().toLowerCase().equals("expiration")){
				session.delete(session.merge(this));
			}
		}
		transaction.commit();
	}
}