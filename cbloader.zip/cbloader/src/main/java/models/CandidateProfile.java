package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import models.common.Payload;
import utils.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "CandidateProfile")
public class CandidateProfile implements Serializable{
	public CandidateProfile(){}

	@Id
	@Column(name = "key")
	@JsonProperty("key")
	@Getter
	@Setter
	public String key;

	@Column(name = "cas")
	@JsonProperty("cas")
	@Getter
	@Setter
	public String cas;

	@Column(name = "bySeqNo")
	@JsonProperty("bySeqNo")
	@Getter
	@Setter
	public BigDecimal bySeqNo;

	@Column(name = "revSeqNo")
	@JsonProperty("revSeqNo")
	@Getter
	@Setter
	public BigDecimal revSeqNo;

//	@Column(name = "AdditionalDocuments")
//	@JsonProperty("AdditionalDocuments")
//	@Getter
//	@Setter
//	public String AdditionalDocuments;

//	@Column(name = "AgencyDistributionAssessment")
//	@JsonProperty("AgencyDistributionAssessment")
//	@Getter
//	@Setter
//	public String AgencyDistributionAssessment;

//	@Column(name = "Avatar")
//	@JsonProperty("Avatar")
//	@Getter
//	@Setter
//	public String Avatar;

//	@Column(name = "BankAccountForm")
//	@JsonProperty("BankAccountForm")
//	@Getter
//	@Setter
//	public String BankAccountForm;

//	@Column(name = "CompliancePolicy")
//	@JsonProperty("CompliancePolicy")
//	@Getter
//	@Setter
//	public String CompliancePolicy;
//
//	@Column(name = "ConfirmLetter")
//	@JsonProperty("ConfirmLetter")
//	@Getter
//	@Setter
//	public String ConfirmLetter;
//
//	@Column(name = "ConfirmOfExperience")
//	@JsonProperty("ConfirmOfExperience")
//	@Getter
//	@Setter
//	public String ConfirmOfExperience;
//
//	@Column(name = "EduCert")
//	@JsonProperty("EduCert")
//	@Getter
//	@Setter
//	public String EduCert;
//
//	@Column(name = "FamilyDocs")
//	@JsonProperty("FamilyDocs")
//	@Getter
//	@Setter
//	public String FamilyDocs;
//
//	@Column(name = "IdentifyPassPort")
//	@JsonProperty("IdentifyPassPort")
//	@Getter
//	@Setter
//	public String IdentifyPassPort;
//
//	@Column(name = "PersonalCurriculum")
//	@JsonProperty("PersonalCurriculum")
//	@Getter
//	@Setter
//	public String PersonalCurriculum;

//	@Column(name = "address")
//	@JsonProperty("address")
//	@Getter
//	@Setter
//	public String address;

//	@Column(name = "bankInfo")
//	@JsonProperty("bankInfo")
//	@Getter
//	@Setter
//	public String bankInfo;

	@Column(name = "candidateID")
	@JsonProperty("candidateID")
	@Getter
	@Setter
	public String candidateID;

	@Column(name = "childs")
	@JsonProperty("childs")
	@Getter
	@Setter
	public String childs;

	@Column(name = "company")
	@JsonProperty("company")
	@Getter
	@Setter
	public String company;

	@Column(name = "contractID")
	@JsonProperty("contractID")
	@Getter
	@Setter
	public String contractID;

	@Column(name = "createdAt")
	@Getter
	@Setter
	public Date createdAt_temp;

	@Transient
	@JsonProperty("createdAt")
	@Getter
	public String createdAt;

	public void setCreatedAt(String ca) throws Exception{
		if(ca != null && !ca.trim().equals("")) {
			this.createdAt_temp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX").parse(ca);
			this.createdAt = ca;
		}
	}

	@Column(name = "dateOfBirth")
	@JsonProperty("dateOfBirth")
	@Getter
	@Setter
	public String dateOfBirth;

	@Column(name = "dteUpdated")
	@JsonProperty("dteUpdated")
	@Getter
	@Setter
	public String dteUpdated;

	@Column(name = "email")
	@JsonProperty("email")
	@Getter
	@Setter
	public String email;

	@Column(name = "ethnicity")
	@JsonProperty("ethnicity")
	@Getter
	@Setter
	public String ethnicity;

	@Column(name = "experienceStatus")
	@JsonProperty("experienceStatus")
	@Getter
	@Setter
	public String experienceStatus;

	@Column(name = "firstName")
	@JsonProperty("firstName")
	@Getter
	@Setter
	public String firstName;

	@Column(name = "fullName")
	@JsonProperty("fullName")
	@Getter
	@Setter
	public String fullName;

	@Column(name = "gender")
	@JsonProperty("gender")
	@Getter
	@Setter
	public String gender;

	@Column(name = "hasAddMissingDocForDA")
	@JsonProperty("hasAddMissingDocForDA")
	@Getter
	@Setter
	public String hasAddMissingDocForDA;

	@Column(name = "hasSubmission")
	@JsonProperty("hasSubmission")
	@Getter
	@Setter
	public String hasSubmission;

//	@Column(name = "idCard")
//	@JsonProperty("idCard")
//	@Getter
//	@Setter
//	public String idCard;

	@Column(name = "idNumber")
	@JsonProperty("idNumber")
	@Getter
	@Setter
	public String idNumber;

//	@Column(name = "imgDocs")
//	@JsonProperty("imgDocs")
//	@Getter
//	@Setter
//	public String imgDocs;

	@Column(name = "income")
	@JsonProperty("income")
	@Getter
	@Setter
	public String income;

	@Column(name = "insuranceCompany")
	@JsonProperty("insuranceCompany")
	@Getter
	@Setter
	public String insuranceCompany;

	@Column(name = "insuranceExperience")
	@JsonProperty("insuranceExperience")
	@Getter
	@Setter
	public String insuranceExperience;

	@Column(name = "isOtherBank")
	@JsonProperty("isOtherBank")
	@Getter
	@Setter
	public String isOtherBank;

	@Column(name = "lastName")
	@JsonProperty("lastName")
	@Getter
	@Setter
	public String lastName;

	@Column(name = "leaderCodeDesc")
	@JsonProperty("leaderCodeDesc")
	@Getter
	@Setter
	public String leaderCodeDesc;

//	@Column(name = "leaderInfo")
//	@JsonProperty("leaderInfo")
//	@Getter
//	@Setter
//	public String leaderInfo;

	@Column(name = "occupation")
	@JsonProperty("occupation")
	@Getter
	@Setter
	public String occupation;

	@Column(name = "occupationID")
	@JsonProperty("occupationID")
	@Getter
	@Setter
	public String occupationID;

//	@Column(name = "otherBank")
//	@JsonProperty("otherBank")
//	@Getter
//	@Setter
//	public String otherBank;

	@Column(name = "otherField")
	@JsonProperty("otherField")
	@Getter
	@Setter
	public String otherField;

	@Column(name = "phoneNumber")
	@JsonProperty("phoneNumber")
	@Getter
	@Setter
	public String phoneNumber;

	@Column(name = "placeOfBirth")
	@JsonProperty("placeOfBirth")
	@Getter
	@Setter
	public String placeOfBirth;

	@Column(name = "qScore")
	@JsonProperty("qScore")
	@Getter
	@Setter
	public String qScore;

	@Column(name = "registerDate")
	@Getter
	@Setter
	public Date registerDate_temp;

	@Transient
	@JsonProperty("registerDate")
	@Getter
	public String registerDate;

	public void setRegisterDate(String rd) throws Exception{
		if(rd != null && !rd.trim().equals("")) {
			this.registerDate_temp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX").parse(rd);
			this.registerDate = rd;
		}
	}

	@Column(name = "rein")
	@JsonProperty("rein")
	@Getter
	@Setter
	public String rein;

	@Column(name = "source")
	@JsonProperty("source")
	@Getter
	@Setter
	public String source;

	@Column(name = "submissionDate")
	@Getter
	@Setter
	public Date submissionDate_temp;

	@Transient
	@JsonProperty("submissionDate")
	@Getter
	public String submissionDate;

	public void setSubmissionDate(String sd) throws Exception {
		if(sd != null && !sd.trim().equals("")) {
			this.submissionDate_temp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX").parse(sd);
			this.submissionDate = sd;
		}
	}

	@Column(name = "traineeId")
	@JsonProperty("traineeId")
	@Getter
	@Setter
	public String traineeId;

	@Column(name = "typekey")
	@JsonProperty("typekey")
	@Getter
	@Setter
	public String typekey;

	public void save(Session session, Payload payload){
		Transaction transaction = session.beginTransaction();
		if(payload.event.trim().toLowerCase().equals("mutation")) {
			session.merge(this);
		}
		else{
			if(payload.event.trim().toLowerCase().equals("deletion") ||
					payload.event.trim().toLowerCase().equals("expiration")){
				session.delete(session.merge(this));
			}
		}
		transaction.commit();
	}
}