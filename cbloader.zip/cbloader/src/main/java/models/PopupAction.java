package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PopupAction {
    @JsonProperty("screenName")
    public String screenName;

    @JsonProperty("tag")
    public String tag;
}
