package models.common;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Payload {
    @JsonProperty("event")
    public String event;

    @JsonProperty("partition")
    public BigDecimal partition;

    @JsonProperty("key")
    public String key;

    @JsonProperty("cas")
    public String cas;

    @JsonProperty("bySeqno")
    public BigDecimal bySeqno;

    @JsonProperty("revSeqno")
    public BigDecimal revSeqno;

    @JsonProperty("expiration")
    public BigDecimal expiration;

    @JsonProperty("flags")
    public BigDecimal flags;

    @JsonProperty("lockTime")
    public BigDecimal lockTime;

    @JsonProperty("content")
    public String content;

    @JsonProperty("bucket")
    public String bucket;

    @JsonProperty("vBucketUuid")
    public String vBucketUuid;
}
