package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import models.common.Payload;
import utils.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "ActiveSaReport")
public class ActiveSaReport implements Serializable{
	public ActiveSaReport(){}

	@Id
	@Column(name = "key")
	@JsonProperty("key")
	@Getter
	@Setter
	public String key;

	@Column(name = "cas")
	@JsonProperty("cas")
	@Getter
	@Setter
	public String cas;

	@Column(name = "bySeqNo")
	@JsonProperty("bySeqNo")
	@Getter
	@Setter
	public BigDecimal bySeqNo;

	@Column(name = "revSeqNo")
	@JsonProperty("revSeqNo")
	@Getter
	@Setter
	public BigDecimal revSeqNo;

	@Column(name = "agentCode")
	@JsonProperty("agentCode")
	@Getter
	@Setter
	public String agentCode;

	@Column(name = "agentName")
	@JsonProperty("agentName")
	@Getter
	@Setter
	public String agentName;

	@Column(name = "createdDate")
	@Getter
	@Setter
	public Date createdDate_temp;

	@Transient
	@JsonProperty("createdDate")
	@Getter
	public String createdDate;

	public void setCreatedDate(String createdDate) throws Exception{
		if(createdDate != null) {
			this.createdDate_temp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX").parse(createdDate);
			this.createdDate = createdDate;
		}
	}

	@Column(name = "createdTime")
	@Getter
	@Setter
	public Date createdTime_temp;

	@Transient
	@JsonProperty("createdTime")
	@Getter
	public BigDecimal createdTime;

	public void setCreatedTime(BigDecimal createdTime) {
		if(createdTime != null) {
			this.createdTime_temp = Utils.convertTimeFromEpoch(createdTime);
			this.createdTime = createdTime;
		}
}

	@Column(name = "idCounter")
	@JsonProperty("idCounter")
	@Getter
	@Setter
	public BigDecimal idCounter;

	@Column(name = "idPrefix")
	@JsonProperty("idPrefix")
	@Getter
	@Setter
	public String idPrefix;

	@Column(name = "leaderCode")
	@JsonProperty("leaderCode")
	@Getter
	@Setter
	public String leaderCode;

	@Column(name = "leaderName")
	@JsonProperty("leaderName")
	@Getter
	@Setter
	public String leaderName;

	@Column(name = "leaderPosition")
	@JsonProperty("leaderPosition")
	@Getter
	@Setter
	public String leaderPosition;

	@Column(name = "type")
	@JsonProperty("type")
	@Getter
	@Setter
	public String type;

	@Column(name = "typekey")
	@JsonProperty("typekey")
	@Getter
	@Setter
	public String typekey;

	@Column(name = "unitCode")
	@JsonProperty("unitCode")
	@Getter
	@Setter
	public String unitCode;

	public void save(Session session, Payload payload){
		Transaction transaction = session.beginTransaction();
		if(payload.event.trim().toLowerCase().equals("mutation")) {
			session.merge(this);
		}
		else{
			if(payload.event.trim().toLowerCase().equals("deletion") ||
					payload.event.trim().toLowerCase().equals("expiration")){
				session.delete(session.merge(this));
			}
		}
		transaction.commit();
	}
}