package models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Sync implements Serializable {

    @JsonProperty("channel")
    public String[] channel;

    public String getChannel(){
        if(channel == null) return "";
        String channelStr = "";
        for(int i = 0; i < channel.length; i++)
        {
            if(i == 0) {
                channelStr += channel[i];
            }
            else {
                channelStr += ", " + channel[i];
            }
        }
        return channelStr;
    }

    @JsonProperty("access")
    public Map<String, Object> access;
    public String getAccessChannel(){
        if(access == null) return "";
        return "";
    }

    public String getAccessUser(){
        if(access == null) return "";
        return "";
    }

    @JsonProperty("requireAdmin")
    public String requireAdmin;
    public String getRequireAdmin(){
        return requireAdmin;
    }

    @JsonProperty("requireUser")
    public String[] requireUser;
    public String getRequireUser(){
        if(requireUser == null) return "";
        String userStr = "";
        for(int i = 0; i < requireUser.length; i++){
            if(i == 0){
                userStr += requireUser[i];
            }
            else{
                userStr += ", " + requireUser[i];
            }
        }
        return userStr;
    }

    @JsonProperty("requireAccess")
    public String[] requireAccess;
    public String getRequireAccess(){
        if(requireAccess == null) return "";
        return "";
    }

    @JsonProperty("expiry")
    public String expiry;
    public Date getExpiry() throws Exception{
        if(expiry == null || expiry.trim().equals("")) return null;
        return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX").parse(expiry);
    }
}
