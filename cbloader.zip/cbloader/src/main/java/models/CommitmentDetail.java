package models;

import com.fasterxml.jackson.annotation.*;
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import models.common.Payload;
import utils.Utils;
import org.hibernate.Session;
import org.hibernate.Transaction;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "CommitmentDetail")
public class CommitmentDetail implements Serializable{
	public CommitmentDetail(){}

	@Id
	@Column(name = "key")
	@JsonProperty("key")
	@Getter
	@Setter
	public String key;

	@Column(name = "cas")
	@JsonProperty("cas")
	@Getter
	@Setter
	public String cas;

	@Column(name = "bySeqNo")
	@JsonProperty("bySeqNo")
	@Getter
	@Setter
	public BigDecimal bySeqNo;

	@Column(name = "revSeqNo")
	@JsonProperty("revSeqNo")
	@Getter
	@Setter
	public BigDecimal revSeqNo;

	@Column(name = "agentCode")
	@JsonProperty("agentCode")
	@Getter
	@Setter
	public String agentCode;

	@Column(name = "apeCommit")
	@JsonProperty("apeCommit")
	@Getter
	@Setter
	public BigDecimal apeCommit;

	@Column(name = "commitmentId")
	@JsonProperty("commitmentId")
	@Getter
	@Setter
	public String commitmentId;

	@Column(name = "committedDate")
	@Getter
	@Setter
	public Date committedDate_temp;

	@Transient
	@JsonProperty("committedDate")
	@Getter
	public BigDecimal committedDate;

	public void setCommittedDate(BigDecimal committedDate) {
		if(committedDate != null) {
			this.committedDate_temp = Utils.convertTimeFromEpoch(committedDate);
			this.committedDate = committedDate;
		}
}

	@Column(name = "contractExpect")
	@JsonProperty("contractExpect")
	@Getter
	@Setter
	public BigDecimal contractExpect;

	@Column(name = "createdDate")
	@Getter
	@Setter
	public Date createdDate_temp;

	@Transient
	@JsonProperty("createdDate")
	@Getter
	public BigDecimal createdDate;

	public void setCreatedDate(BigDecimal createdDate) {
		if(createdDate != null) {
			this.createdDate_temp = Utils.convertTimeFromEpoch(createdDate);
			this.createdDate = createdDate;
		}
}

	@Column(name = "customerCommit")
	@JsonProperty("customerCommit")
	@Getter
	@Setter
	public BigDecimal customerCommit;

	@Column(name = "idCounter")
	@JsonProperty("idCounter")
	@Getter
	@Setter
	public BigDecimal idCounter;

	@Column(name = "idPrefix")
	@JsonProperty("idPrefix")
	@Getter
	@Setter
	public String idPrefix;

	@Column(name = "officeCode")
	@JsonProperty("officeCode")
	@Getter
	@Setter
	public String officeCode;

	@Column(name = "status")
	@JsonProperty("status")
	@Getter
	@Setter
	public String status;

	@Column(name = "typekey")
	@JsonProperty("typekey")
	@Getter
	@Setter
	public String typekey;

	@Column(name = "unitCode")
	@JsonProperty("unitCode")
	@Getter
	@Setter
	public String unitCode;

	@Column(name = "updateDate")
	@Getter
	@Setter
	public Date updateDate_temp;

	@Transient
	@JsonProperty("updateDate")
	@Getter
	public BigDecimal updateDate;

	public void setUpdateDate(BigDecimal updateDate) {
		if(updateDate != null) {
			this.updateDate_temp = Utils.convertTimeFromEpoch(updateDate);
			this.updateDate = updateDate;
		}
	}

	public void save(Session session, Payload payload){
		Transaction transaction = session.beginTransaction();
		if(payload.event.trim().toLowerCase().equals("mutation")) {
			session.merge(this);
		}
		else{
			if(payload.event.trim().toLowerCase().equals("deletion") ||
					payload.event.trim().toLowerCase().equals("expiration")){
				session.delete(session.merge(this));
			}
		}
		transaction.commit();
	}
}