import com.couchbase.client.java.Bucket;
import com.couchbase.client.java.Cluster;
import com.couchbase.client.java.CouchbaseCluster;
import com.couchbase.client.java.query.N1qlQuery;
import com.couchbase.client.java.query.N1qlQueryResult;
import com.couchbase.client.java.query.N1qlQueryRow;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import models.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.atomic.AtomicLong;

public class CBLoader {
    public static void main(String[] args) throws Exception {
        org.hibernate.cfg.Configuration hibernateConfiguration;
        SessionFactory sessionFactory;

        String jdbc_url = "jdbc:oracle:thin:@192.168.1.160:1521:dwdb", jdbc_usr = "agentdta", jdbc_pwd = "agent2019";
        String hibernateConfigFile = "file:///C:/java/new/hibernate_new.cfg.xml";

        hibernateConfiguration = new org.hibernate.cfg.Configuration().configure(hibernateConfigFile);
        sessionFactory = hibernateConfiguration.buildSessionFactory();

        Cluster cluster = CouchbaseCluster.create("192.168.1.160");
        cluster.authenticate("Administrator", "admin123");
        Bucket uatBucket = cluster.openBucket("agentapp_uat");
        Bucket livestreamBucket = cluster.openBucket("agentapp_livestream");
        Bucket candidateBucket = cluster.openBucket("agentapp_candidate");
        Bucket otpBucket = cluster.openBucket("agentapp_otp");

        ObjectMapper mapper = new ObjectMapper();

        System.out.println("Start time: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSX").format(new Date()));

        long count = 0l;
        System.out.print("ActionTracking: ");
        N1qlQueryResult actionTrackingResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.ActionTracking'"));
        for (N1qlQueryRow row: actionTrackingResult.allRows()) {
            try {
                ActionTracking actionTracking = mapper.readValue(row.value().get("agentapp_uat").toString(), ActionTracking.class);
                actionTracking.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(actionTracking);
                    transaction.commit();
                    if(count % 1000 == 0)
                    if(count % 1000 == 0) System.out.print("."); count++;;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("QRCode: ");
        N1qlQueryResult qRCodeResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.QRCode'"));
        for (N1qlQueryRow row: qRCodeResult.allRows()) {
            try {
                QRCode qRCode = mapper.readValue(row.value().get("agentapp_uat").toString(), QRCode.class);
                qRCode.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(qRCode);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("DeviceToken: ");
        N1qlQueryResult deviceTokenResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.DeviceToken'"));
        for (N1qlQueryRow row: deviceTokenResult.allRows()) {
            try {
                DeviceToken deviceToken = mapper.readValue(row.value().get("agentapp_uat").toString(), DeviceToken.class);
                deviceToken.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(deviceToken);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("ActiveSa: ");
        N1qlQueryResult activeSaResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.ActiveSa'"));
        for (N1qlQueryRow row: activeSaResult.allRows()) {
            try {
                ActiveSa activeSa = mapper.readValue(row.value().get("agentapp_uat").toString(), ActiveSa.class);
                activeSa.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(activeSa);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);


        count = 0L;
        System.out.print("ActiveSaReport: ");
        N1qlQueryResult activeSaReportResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.ActiveSaReport'"));
        for (N1qlQueryRow row: activeSaReportResult.allRows()) {
            try {
                ActiveSaReport activeSaReport = mapper.readValue(row.value().get("agentapp_uat").toString(), ActiveSaReport.class);
                activeSaReport.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(activeSaReport);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("Attachment: ");
        N1qlQueryResult attachmentResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key` FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.Attachment'"));
        for (N1qlQueryRow row: attachmentResult.allRows()) {
//            try {
//                Attachment attachment = mapper.readValue(row.value().get("agentapp_uat").toString(), Attachment.class);
//                attachment.key = row.value().get("key").toString();
//                try (Session session = sessionFactory.openSession()) {
//                    Transaction transaction = session.beginTransaction();
//                    session.merge(attachment);
//                    transaction.commit();
//                    if(count % 1000 == 0) System.out.print("."); count++;
//                }
//                catch (Exception ex){
//                    ex.printStackTrace();
//                }
//            } catch (JsonProcessingException e) {
//                e.printStackTrace();
//            }
            if(count % 1000 == 0) System.out.print("."); count++;
        }
        System.out.println(count);

        count = 0L;
        System.out.print("CommitmentDetail: ");
        N1qlQueryResult commitmentDetailResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.CommitmentDetail'"));
        for (N1qlQueryRow row: commitmentDetailResult.allRows()) {
            try {
                CommitmentDetail commitmentDetail = mapper.readValue(row.value().get("agentapp_uat").toString(), CommitmentDetail.class);
                commitmentDetail.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(commitmentDetail);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("CommitmentGroup: ");
        N1qlQueryResult commitmentGroupResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.CommitmentGroup'"));
        for (N1qlQueryRow row: commitmentGroupResult.allRows()) {
            try {
                CommitmentGroup commitmentGroup = mapper.readValue(row.value().get("agentapp_uat").toString(), CommitmentGroup.class);
                commitmentGroup.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(commitmentGroup);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("EarnPointHistory: ");
        N1qlQueryResult earnPointHistoryResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.EarnPointHistory'"));
        for (N1qlQueryRow row: earnPointHistoryResult.allRows()) {
            try {
                EarnPointHistory earnPointHistory = mapper.readValue(row.value().get("agentapp_uat").toString(), EarnPointHistory.class);
                earnPointHistory.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(earnPointHistory);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("HistoryCheckIn: ");
        N1qlQueryResult historyCheckInResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.HistoryCheckIn'"));
        for (N1qlQueryRow row: historyCheckInResult.allRows()) {
            try {
                HistoryCheckIn historyCheckIn = mapper.readValue(row.value().get("agentapp_uat").toString(), HistoryCheckIn.class);
                historyCheckIn.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(historyCheckIn);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("Message: ");
        N1qlQueryResult messageResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.Message'"));
        for (N1qlQueryRow row: messageResult.allRows()) {
            try {
                Message message = mapper.readValue(row.value().get("agentapp_uat").toString(), Message.class);
                message.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(message);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("MessageDetail: ");
        N1qlQueryResult messageDetailResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.MessageDetail'"));
        for (N1qlQueryRow row: messageDetailResult.allRows()) {
            try {
                MessageDetail messageDetail = mapper.readValue(row.value().get("agentapp_uat").toString(), MessageDetail.class);
                messageDetail.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(messageDetail);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("QRCodeContent: ");
        N1qlQueryResult qRCodeContentResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.QRCodeContent'"));
        for (N1qlQueryRow row: qRCodeContentResult.allRows()) {
            try {
                QRCodeContent qRCodeContent = mapper.readValue(row.value().get("agentapp_uat").toString(), QRCodeContent.class);
                qRCodeContent.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(qRCodeContent);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("ReferralCode: ");
        N1qlQueryResult referralCodeResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.ReferralCode'"));
        for (N1qlQueryRow row: referralCodeResult.allRows()) {
            try {
                ReferralCode referralCode = mapper.readValue(row.value().get("agentapp_uat").toString(), ReferralCode.class);
                referralCode.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(referralCode);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("RegisterAgent: ");
        N1qlQueryResult registerAgentResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.RegisterAgent'"));
        for (N1qlQueryRow row: registerAgentResult.allRows()) {
            try {
                RegisterAgent registerAgent = mapper.readValue(row.value().get("agentapp_uat").toString(), RegisterAgent.class);
                registerAgent.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(registerAgent);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("RewardPoint: ");
        N1qlQueryResult rewardPointResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.RewardPoint'"));
        for (N1qlQueryRow row: rewardPointResult.allRows()) {
            try {
                RewardPoint rewardPoint = mapper.readValue(row.value().get("agentapp_uat").toString(), RewardPoint.class);
                rewardPoint.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(rewardPoint);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("Users: ");
        N1qlQueryResult usersResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.Users'"));
        for (N1qlQueryRow row: usersResult.allRows()) {
            try {
                Users users = mapper.readValue(row.value().get("agentapp_uat").toString(), Users.class);
                users.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(users);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("Candidate: ");
        N1qlQueryResult candidateResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='Candidate'"));
        for (N1qlQueryRow row: candidateResult.allRows()) {
            try {
                Candidate candidate = mapper.readValue(row.value().get("agentapp_uat").toString(), Candidate.class);
                candidate.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(candidate);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("WelcomePopup: ");
        N1qlQueryResult welcomePopupResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='WelcomePopup'"));
        for (N1qlQueryRow row: welcomePopupResult.allRows()) {
            try {
                WelcomePopup welcomePopup = mapper.readValue(row.value().get("agentapp_uat").toString(), WelcomePopup.class);
                welcomePopup.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(welcomePopup);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("SyncUserGroup: ");
        N1qlQueryResult syncUserGroupResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='SyncUserGroup'"));
        for (N1qlQueryRow row: syncUserGroupResult.allRows()) {
            try {
                SyncUserGroup syncUserGroup = mapper.readValue(row.value().get("agentapp_uat").toString(), SyncUserGroup.class);
                syncUserGroup.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(syncUserGroup);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("LivestreamComment: ");
        N1qlQueryResult livestreamCommentResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_livestream WHERE typekey='LivestreamComment'"));
        for (N1qlQueryRow row: livestreamCommentResult.allRows()) {
            try {
                LivestreamComment livestreamComment = mapper.readValue(row.value().get("agentapp_livestream").toString(), LivestreamComment.class);
                livestreamComment.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(livestreamComment);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("LivestreamActivity: ");
        N1qlQueryResult livestreamActivityResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_livestream WHERE typekey='LivestreamActivity'"));
        for (N1qlQueryRow row: livestreamActivityResult.allRows()) {
            try {
                LivestreamActivity livestreamActivity = mapper.readValue(row.value().get("agentapp_livestream").toString(), LivestreamActivity.class);
                livestreamActivity.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(livestreamActivity);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("LivestreamLike: ");
        N1qlQueryResult livestreamLikeResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_livestream WHERE typekey='LivestreamLike'"));
        for (N1qlQueryRow row: livestreamLikeResult.allRows()) {
            try {
                LivestreamLike livestreamLike = mapper.readValue(row.value().get("agentapp_livestream").toString(), LivestreamLike.class);
                livestreamLike.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(livestreamLike);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("Livestream: ");
        N1qlQueryResult livestreamResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_livestream WHERE typekey='Livestream'"));
        for (N1qlQueryRow row: livestreamResult.allRows()) {
            try {
                Livestream livestream = mapper.readValue(row.value().get("agentapp_livestream").toString(), Livestream.class);
                livestream.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(livestream);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        System.out.print("LivestreamAdmin: ");
        N1qlQueryResult livestreamAdminResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_livestream WHERE typekey='LivestreamAdmin'"));
        for (N1qlQueryRow row: livestreamAdminResult.allRows()) {
            try {
                LivestreamAdmin livestreamAdmin = mapper.readValue(row.value().get("agentapp_livestream").toString(), LivestreamAdmin.class);
                livestreamAdmin.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(livestreamAdmin);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("LivestreamUserGroup: ");
        N1qlQueryResult livestreamUserGroupResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_livestream WHERE typekey='LivestreamUserGroup'"));
        for (N1qlQueryRow row: livestreamUserGroupResult.allRows()) {
            try {
                LivestreamUserGroup livestreamUserGroup = mapper.readValue(row.value().get("agentapp_livestream").toString(), LivestreamUserGroup.class);
                livestreamUserGroup.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(livestreamUserGroup);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("UserLiveStream: ");
        N1qlQueryResult userLiveStreamResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_livestream WHERE typekey='UserLiveStream'"));
        for (N1qlQueryRow row: userLiveStreamResult.allRows()) {
            try {
                UserLiveStream userLiveStream = mapper.readValue(row.value().get("agentapp_livestream").toString(), UserLiveStream.class);
                userLiveStream.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(userLiveStream);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("OTPRecord: ");
        N1qlQueryResult oTPRecordResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_otp WHERE typekey='OTPRecord'"));
        for (N1qlQueryRow row: oTPRecordResult.allRows()) {
            try {
                OTPRecord oTPRecord = mapper.readValue(row.value().get("agentapp_otp").toString(), OTPRecord.class);
                oTPRecord.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(oTPRecord);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("CandidateProfile: ");
        N1qlQueryResult candidateProfileResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_candidate WHERE typekey='CandidateProfile'"));
        for (N1qlQueryRow row: candidateProfileResult.allRows()) {
            try {
                CandidateProfile candidateProfile = mapper.readValue(row.value().get("agentapp_candidate").toString(), CandidateProfile.class);
                candidateProfile.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(candidateProfile);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("PotentialCustomerTrack: ");
        N1qlQueryResult potentialCustomerTrackResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_candidate WHERE typekey='PotentialCustomerTrack'"));
        for (N1qlQueryRow row: potentialCustomerTrackResult.allRows()) {
            try {
                PotentialCustomerTrack potentialCustomerTrack = mapper.readValue(row.value().get("agentapp_candidate").toString(), PotentialCustomerTrack.class);
                potentialCustomerTrack.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(potentialCustomerTrack);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("CandidateAssessment: ");
        N1qlQueryResult candidateAssessmentResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_candidate WHERE typekey='CandidateAssessment'"));
        for (N1qlQueryRow row: candidateAssessmentResult.allRows()) {
            try {
                CandidateAssessment candidateAssessment = mapper.readValue(row.value().get("agentapp_candidate").toString(), CandidateAssessment.class);
                candidateAssessment.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(candidateAssessment);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("AgentAddress: ");
        N1qlQueryResult agentAddressResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.AgentAddress'"));
        for (N1qlQueryRow row: agentAddressResult.allRows()) {
            try {
                AgentAddress agentAddress = mapper.readValue(row.value().get("agentapp_uat").toString(), AgentAddress.class);
                agentAddress.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(agentAddress);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("NotificationGroup: ");
        N1qlQueryResult notificationGroupResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.NotificationGroup'"));
        for (N1qlQueryRow row: notificationGroupResult.allRows()) {
            try {
                NotificationGroup notificationGroup = mapper.readValue(row.value().get("agentapp_uat").toString(), NotificationGroup.class);
                notificationGroup.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(notificationGroup);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("AgentEvent: ");
        N1qlQueryResult AgentEventResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.AgentEvent'"));
        for (N1qlQueryRow row: AgentEventResult.allRows()) {
            try {
                AgentEvent agentEvent = mapper.readValue(row.value().get("agentapp_uat").toString(), AgentEvent.class);
                agentEvent.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(agentEvent);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("AgentProfile: ");
        N1qlQueryResult agentProfileResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.AgentProfile'"));
        for (N1qlQueryRow row: agentProfileResult.allRows()) {
            try {
                AgentProfile agentProfile = mapper.readValue(row.value().get("agentapp_uat").toString(), AgentProfile.class);
                agentProfile.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(agentProfile);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("AuthTrack: ");
        N1qlQueryResult authTrackResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.AuthTrack'"));
        for (N1qlQueryRow row: authTrackResult.allRows()) {
            try {
                AuthTrack authTrack = mapper.readValue(row.value().get("agentapp_uat").toString(), AuthTrack.class);
                authTrack.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(authTrack);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        count = 0L;
        System.out.print("MasterPointConfig: ");
        N1qlQueryResult masterPointConfigResult = uatBucket.query(N1qlQuery.simple("SELECT meta().id as `key`, * FROM agentapp_uat WHERE typekey='vn.com.prudential.agentapp.entity.MasterPointConfig'"));
        for (N1qlQueryRow row: masterPointConfigResult.allRows()) {
            try {
                MasterPointConfig masterPointConfig = mapper.readValue(row.value().get("agentapp_uat").toString(), MasterPointConfig.class);
                masterPointConfig.key = row.value().get("key").toString();
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.merge(masterPointConfig);
                    transaction.commit();
                    if(count % 1000 == 0) System.out.print("."); count++;
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        System.out.println(count);

        uatBucket.close();
        livestreamBucket.close();
        candidateBucket.close();
        otpBucket.close();
        cluster.disconnect();

        System.out.println("End time: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSX").format(new Date()));
    }
}
